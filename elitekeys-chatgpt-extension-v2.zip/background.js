// EliteKeys ChatGPT v2 — service worker.
// Responsibilities:
//   1. Block Google "Welcome back" SSO requests on chatgpt.com (declarativeNetRequest).
//   2. Wipe stale ChatGPT auth cookies, then insert the pool account cookies (HttpOnly-safe
//      via chrome.cookies.set), and reload into a working profile.
//   3. Kill "Welcome back" / "session expired" overlays in the page (MAIN world).
// CRITICAL (Chrome): tabs.Tab has NO cookieStoreId. Incognito is store "1";
// the service worker defaults to store "0". Writing the JWT to the wrong jar
// reloads chatgpt.com as a guest (Log in / Sign up) even though Unlock "succeeded".

const CF_KEEP = { cf_clearance: 1, __cf_bm: 1, _cfuvid: 1, __cflb: 1 };
const COOKIE_MAX_AGE_SEC = 60 * 60 * 24 * 30;

const SITE_ORIGINS = [
  "https://chatgpt.com",
  "https://www.chatgpt.com",
  "https://chat.openai.com",
  "https://auth.openai.com",
  "https://openai.com",
  "https://www.openai.com",
];

function isAuthCookieName(name) {
  const n = String(name || "");
  return (
    n.indexOf("__Secure-next-auth.session-token") === 0 ||
    n.indexOf("__Secure-next-auth.") === 0 ||
    n.indexOf("__Host-next-auth.") === 0 ||
    n === "oai-did" ||
    n === "oai-nav-state" ||
    n === "oai-client-auth-info" ||
    n === "_account" ||
    n.indexOf("next-auth.") === 0
  );
}

function isSessionCookieName(name) {
  return String(name || "").indexOf("__Secure-next-auth.session-token") === 0;
}

/**
 * Inject order. A live ChatGPT tab will mint a fresh oai-did the moment we
 * wipe the jar; Sentinel then treats the session as chatgpt-noauth — Plus/Go
 * UI, conversation created, blue dot, no tokens. Set the harvested device id
 * first, session token last, and never do this while the SPA is still running.
 */
function skipInjectCookie(name) {
  const n = String(name || "");
  if (CF_KEEP[n]) return true;
  // Harvested CSRF is from another device. ChatGPT mints a fresh
  // __Host-next-auth.csrf-token on the buyer's homepage; a stale one 403s POSTs.
  if (/csrf-token/i.test(n)) return true;
  return false;
}

function cookieInjectRank(name) {
  const n = String(name || "");
  if (n === "oai-did") return 0;
  if (n === "oai-client-auth-info" || n === "_account" || n === "oai-nav-state") return 1;
  if (isSessionCookieName(n)) return 3;
  return 2;
}

function getAllCookieStores() {
  return new Promise((resolve) => {
    try {
      chrome.cookies.getAllCookieStores((stores) => resolve(stores || []));
    } catch (e) {
      resolve([]);
    }
  });
}

/** Chrome tabs have no cookieStoreId — map tabId via getAllCookieStores(). */
async function getStoreIdForTab(tabId) {
  if (tabId == null) return undefined;
  for (let n = 0; n < 12; n++) {
    const stores = await getAllCookieStores();
    const hit = stores.find((s) => (s.tabIds || []).indexOf(tabId) >= 0);
    if (hit && hit.id != null) return String(hit.id);
    await new Promise((r) => setTimeout(r, 50 + n * 40));
  }
  return undefined;
}

async function resolveStoreId(sender, explicit) {
  if (explicit != null && explicit !== "") return String(explicit);
  if (sender && sender.tab && sender.tab.cookieStoreId) {
    return String(sender.tab.cookieStoreId);
  }
  const tabId = sender && sender.tab && sender.tab.id != null ? sender.tab.id : null;
  if (tabId != null) {
    const fromTab = await getStoreIdForTab(tabId);
    if (fromTab) return fromTab;
    if (sender.tab && sender.tab.incognito) {
      const stores = await getAllCookieStores();
      const nonDefault = stores.find((s) => s && String(s.id) !== "0");
      if (nonDefault) return String(nonDefault.id);
    }
  }
  return undefined;
}

function assertStoreSafeForSender(sender, storeId) {
  const incog = !!(sender && sender.tab && sender.tab.incognito);
  if (!incog) return { ok: true, storeId: storeId || null };
  if (!storeId || String(storeId) === "0") {
    return {
      ok: false,
      error:
        "This Incognito tab cannot see EliteKeys cookies. Enable Allow in Incognito for the extension, then try Log in to ChatGPT again.",
    };
  }
  return { ok: true, storeId: String(storeId) };
}

function getCookieExact(url, name, storeId, partitionKey) {
  return new Promise((resolve) => {
    try {
      const opts = { url, name };
      if (storeId) opts.storeId = storeId;
      if (partitionKey) opts.partitionKey = partitionKey;
      chrome.cookies.get(opts, (c) => resolve(c || null));
    } catch (e) {
      resolve(null);
    }
  });
}

/** Set one cookie into the tab's cookie store (HttpOnly session + partition mirror). */
function setCookie(details, storeId) {
  return new Promise((resolve) => {
    const name = String(details.name || "");
    const value = String(details.value || "");
    const path = details.path || "/";
    const secure =
      details.secure !== false ||
      name.indexOf("__Secure-") === 0 ||
      name.indexOf("__Host-") === 0;
    const httpOnly =
      details.httpOnly === true ||
      isSessionCookieName(name) ||
      name.indexOf("__Secure-") === 0 ||
      name.indexOf("__Host-") === 0;
    const expirationDate =
      details.expirationDate || Math.floor(Date.now() / 1000) + COOKIE_MAX_AGE_SEC;
    const isSession = isSessionCookieName(name);

    const push = (row) => {
      if (storeId) row.storeId = storeId;
      attempts.push(row);
    };
    const attempts = [];
    push({
      url: "https://chatgpt.com/",
      name,
      value,
      path,
      secure,
      httpOnly,
      sameSite: "lax",
      expirationDate,
    });
    if (isSession) {
      push({
        url: "https://chatgpt.com/",
        name,
        value,
        path,
        secure,
        httpOnly,
        sameSite: "lax",
        expirationDate,
        partitionKey: { topLevelSite: "https://chatgpt.com" },
      });
    }
    if (!isSession && name.indexOf("__Host-") !== 0) {
      push({
        url: "https://chatgpt.com/",
        name,
        value,
        path,
        secure,
        httpOnly,
        sameSite: "lax",
        expirationDate,
        domain: ".chatgpt.com",
      });
    }

    let i = 0;
    const next = () => {
      if (i >= attempts.length) {
        resolve({ ok: false, name });
        return;
      }
      const cfg = attempts[i++];
      try {
        chrome.cookies.set(cfg, async (c) => {
          if (chrome.runtime.lastError || !c) {
            next();
            return;
          }
          const got = await getCookieExact(cfg.url, name, storeId || c.storeId, cfg.partitionKey);
          if (!got || got.value !== value) {
            next();
            return;
          }
          if (isSession && got.httpOnly !== true) {
            next();
            return;
          }
          if (storeId && got.storeId && String(got.storeId) !== String(storeId)) {
            next();
            return;
          }
          if (isSession) {
            const mirror = {
              url: "https://chatgpt.com/",
              name,
              value,
              path,
              secure,
              httpOnly,
              sameSite: "lax",
              expirationDate,
            };
            if (storeId) mirror.storeId = storeId;
            if (!cfg.partitionKey) mirror.partitionKey = { topLevelSite: "https://chatgpt.com" };
            try {
              chrome.cookies.set(mirror, () => {});
            } catch (eMirror) {}
          }
          resolve({ ok: true, name, storeId: storeId || got.storeId || null });
        });
      } catch (e) {
        next();
      }
    };
    next();
  });
}

function removeOne(details) {
  return new Promise((resolve) => {
    try {
      chrome.cookies.remove(details, () => resolve(true));
    } catch (e) {
      resolve(false);
    }
  });
}

function browsingDataWipe() {
  return new Promise((resolve) => {
    try {
      if (!chrome.browsingData || typeof chrome.browsingData.remove !== "function") {
        resolve({ ok: false });
        return;
      }
      chrome.browsingData.remove(
        { origins: SITE_ORIGINS, since: 0 },
        { cookies: true, localStorage: true, indexedDB: true, cacheStorage: true, serviceWorkers: true },
        () => resolve({ ok: !chrome.runtime.lastError }),
      );
    } catch (e) {
      resolve({ ok: false });
    }
  });
}

function getAllCookies(query) {
  return new Promise((resolve) => {
    try {
      chrome.cookies.getAll(query || {}, (cookies) => resolve(cookies || []));
    } catch (e) {
      resolve([]);
    }
  });
}

async function wipeAuthCookies(storeId) {
  // browsingData has no storeId — never run it against Incognito (would hit store 0).
  const isDefaultStore = !storeId || storeId === "0";
  if (isDefaultStore) await browsingDataWipe();

  const withStore = (q) => (storeId ? { ...q, storeId } : q);
  const queries = [
    withStore({ domain: "chatgpt.com" }),
    withStore({ domain: "chatgpt.com", partitionKey: {} }),
    withStore({ url: "https://chatgpt.com/" }),
    withStore({ url: "https://chatgpt.com/", partitionKey: { topLevelSite: "https://chatgpt.com" } }),
    withStore({ domain: "openai.com" }),
    withStore({ url: "https://auth.openai.com/" }),
  ];
  const found = [];
  for (const q of queries) found.push(...(await getAllCookies(q)));

  const targets = found.filter((c) => {
    if (!c || !c.name || CF_KEEP[c.name]) return false;
    const host = String(c.domain || "").replace(/^\./, "");
    return /chatgpt\.com$/i.test(host) || /openai\.com$/i.test(host) || isAuthCookieName(c.name);
  });

  const known = [
    "__Secure-next-auth.session-token",
    "__Secure-next-auth.session-token.0",
    "__Secure-next-auth.session-token.1",
    "__Secure-next-auth.callback-url",
    "__Host-next-auth.csrf-token",
    "oai-did",
    "oai-nav-state",
    "oai-client-auth-info",
    "_account",
  ];
  for (const name of known) {
    targets.push({ name, path: "/", domain: "chatgpt.com" });
    targets.push({ name, path: "/", domain: ".chatgpt.com" });
  }

  const jobs = [];
  for (const c of targets) {
    if (CF_KEEP[c.name]) continue;
    for (const url of ["https://chatgpt.com/", "https://www.chatgpt.com/", "https://auth.openai.com/"]) {
      const base = storeId ? { url, name: c.name, storeId } : { url, name: c.name };
      jobs.push(removeOne(base));
      jobs.push(removeOne({ ...base, partitionKey: {} }));
      jobs.push(removeOne({ ...base, partitionKey: { topLevelSite: "https://chatgpt.com" } }));
    }
  }
  await Promise.all(jobs);
  return { ok: true };
}

const GOOGLE_SSO_RULE_IDS = [9201, 9202, 9203, 9204];

function setGoogleSsoBlocked(enabled) {
  return new Promise((resolve) => {
    try {
      if (!chrome.declarativeNetRequest || !chrome.declarativeNetRequest.updateDynamicRules) {
        resolve({ ok: false });
        return;
      }
      const initiatorDomains = [
        "chatgpt.com",
        "www.chatgpt.com",
        "chat.openai.com",
        "openai.com",
        "auth.openai.com",
      ];
      const filters = [
        "||accounts.google.com^",
        "||account.google.com^",
        "||ogs.google.com^",
        "||accounts.youtube.com^",
      ];
      const addRules = enabled
        ? filters.map((urlFilter, i) => ({
            id: GOOGLE_SSO_RULE_IDS[i],
            priority: 1,
            action: { type: "block" },
            condition: {
              urlFilter,
              initiatorDomains,
              resourceTypes: ["main_frame", "sub_frame", "xmlhttprequest", "script", "image", "other"],
            },
          }))
        : [];
      chrome.declarativeNetRequest.updateDynamicRules(
        { removeRuleIds: GOOGLE_SSO_RULE_IDS, addRules },
        () => resolve({ ok: !chrome.runtime.lastError, enabled: !!enabled }),
      );
    } catch (e) {
      resolve({ ok: false });
    }
  });
}

function mainWorldKillWelcome(tabId) {
  return new Promise((resolve) => {
    if (tabId == null || !chrome.scripting || !chrome.scripting.executeScript) {
      resolve({ ok: false });
      return;
    }
    chrome.scripting.executeScript(
      {
        target: { tabId },
        world: "MAIN",
        func: () => {
          try {
            const isUi = (el) => {
              try {
                return !!(el && el.closest && el.closest("#ek2-fab,#ek2-panel"));
              } catch (e) {
                return false;
              }
            };
            const looksExpired = (tx) => {
              const t = String(tx || "");
              if (/your session has expired/i.test(t) && /please log in again|log in again/i.test(t)) return true;
              if (/session has expired/i.test(t) && /\blog in\b/i.test(t)) return true;
              if (/session expired/i.test(t) && /continue using the app/i.test(t)) return true;
              return false;
            };
            const looksWelcome = (tx) => {
              const t = String(tx || "");
              return /Welcome back|Choose an account|Log in to another account|@gmail\.com/i.test(t);
            };
            const looksTrap = (tx) => looksExpired(tx) || looksWelcome(tx);
            const neutralize = (n) => {
              if (!n || isUi(n)) return;
              try {
                if (typeof n.close === "function" && n.open) n.close();
              } catch (e0) {}
              try {
                n.setAttribute("data-ek2-hidden", "1");
                n.style.setProperty("display", "none", "important");
                n.style.setProperty("visibility", "hidden", "important");
                n.style.setProperty("opacity", "0", "important");
                n.style.setProperty("pointer-events", "none", "important");
              } catch (e1) {}
            };
            const unfreeze = () => {
              try {
                [document.documentElement, document.body].forEach((el) => {
                  if (!el || !el.style) return;
                  el.style.removeProperty("pointer-events");
                  el.style.setProperty("pointer-events", "auto", "important");
                  try {
                    el.removeAttribute("inert");
                  } catch (eI) {}
                });
              } catch (eU) {}
            };
            const kill = () => {
              const t = String((document.body && (document.body.textContent || "")) || "");
              if (!looksTrap(t)) return;
              document
                .querySelectorAll("div[role='dialog'],dialog,[aria-modal='true'],[popover]")
                .forEach((n) => {
                  if (isUi(n)) return;
                  const tx = String(n.textContent || "");
                  if (!looksTrap(tx)) return;
                  neutralize(n);
                });
              unfreeze();
            };
            kill();
            if (!window.__ek2WelcomeKiller) {
              window.__ek2WelcomeKiller = 1;
              setInterval(kill, 300);
              try {
                new MutationObserver(kill).observe(document.documentElement, {
                  childList: true,
                  subtree: true,
                });
              } catch (eMo) {}
              try {
                document.addEventListener(
                  "click",
                  (e) => {
                    const tgt = e && e.target;
                    if (!tgt || !tgt.closest) return;
                    const dlg = tgt.closest("div[role='dialog'],dialog,[aria-modal='true']");
                    if (!dlg || isUi(dlg)) return;
                    const tx = String(dlg.textContent || "");
                    if (!looksTrap(tx)) return;
                    e.preventDefault();
                    e.stopPropagation();
                    neutralize(dlg);
                    unfreeze();
                  },
                  true,
                );
              } catch (eClk) {}
            }
            return { ok: true };
          } catch (e) {
            return { ok: false };
          }
        },
      },
      (results) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false });
          return;
        }
        resolve((results && results[0] && results[0].result) || { ok: true });
      },
    );
  });
}

function reloadTab(tabId, url) {
  const target = url || `https://chatgpt.com/?ek=${Date.now()}`;
  return new Promise((resolve) => {
    try {
      if (tabId != null) {
        chrome.tabs.update(tabId, { url: target }, () =>
          resolve({ ok: !chrome.runtime.lastError }),
        );
      } else {
        chrome.tabs.create({ url: target, active: true }, () =>
          resolve({ ok: !chrome.runtime.lastError }),
        );
      }
    } catch (e) {
      resolve({ ok: false });
    }
  });
}

function installAuthHook(tabId) {
  return new Promise((resolve) => {
    if (tabId == null || !chrome.scripting || !chrome.scripting.executeScript) {
      resolve({ ok: false });
      return;
    }
    chrome.scripting.executeScript(
      {
        target: { tabId },
        world: "MAIN",
        func: () => {
          try {
            if (window.__ek2AuthHook) return { ok: true, already: true };
            window.__ek2AuthHook = 1;
            // Conversation only. Session/me 401s during hydrate are normal and must
            // not force an unlock swap (phone Activating → refresh loop).
            const interesting = /\/backend-api\/(?:f\/)?conversation/;
            const fire = (url, status, jsonish) => {
              if (status !== 401 && status !== 403) return;
              // Cloudflare 403 is HTML, not a dead JWT — don't treat as auth fail.
              if (status === 403 && !jsonish) return;
              try {
                document.dispatchEvent(
                  new CustomEvent("ek2-auth-fail", {
                    bubbles: true,
                    detail: { url: String(url || ""), status: status },
                  }),
                );
              } catch (e) {}
            };
            const isJson = (res) => {
              try {
                const ct = String((res && res.headers && res.headers.get("content-type")) || "");
                return ct.indexOf("json") >= 0;
              } catch (e) {
                return false;
              }
            };
            const nativeFetch = window.fetch;
            window.fetch = function () {
              const req = arguments[0];
              const url = (req && req.url) || req;
              return nativeFetch.apply(this, arguments).then((res) => {
                try {
                  if (interesting.test(String(url))) fire(url, res.status, isJson(res));
                } catch (e) {}
                return res;
              });
            };
            const xhrOpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function (method, url) {
              this.__ek2url = url;
              return xhrOpen.apply(this, arguments);
            };
            const xhrSend = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.send = function () {
              this.addEventListener("loadend", function () {
                try {
                  const ct = String(this.getResponseHeader("content-type") || "");
                  if (interesting.test(String(this.__ek2url))) {
                    fire(this.__ek2url, this.status, ct.indexOf("json") >= 0);
                  }
                } catch (e) {}
              });
              return xhrSend.apply(this, arguments);
            };
            return { ok: true };
          } catch (e) {
            return { ok: false };
          }
        },
      },
      () => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false });
          return;
        }
        resolve({ ok: true });
      },
    );
  });
}

function parkTab(tabId) {
  return new Promise((resolve) => {
    if (tabId == null) {
      resolve({ ok: true, skipped: true });
      return;
    }
    try {
      chrome.tabs.update(tabId, { url: "about:blank" }, () => {
        setTimeout(() => resolve({ ok: !chrome.runtime.lastError }), 350);
      });
    } catch (e) {
      resolve({ ok: false });
    }
  });
}

async function cookieIsPresent(name, storeId) {
  const got = await getCookieExact("https://chatgpt.com/", name, storeId);
  if (got && got.value) return true;
  const part = await getCookieExact("https://chatgpt.com/", name, storeId, {
    topLevelSite: "https://chatgpt.com",
  });
  return !!(part && part.value);
}

/** Full unlock: kill the SPA, wipe stale auth in THIS tab's jar, insert pool cookies, reload. */
async function unlock(cookies, tabId, sender) {
  await setGoogleSsoBlocked(true);
  const storeId = await resolveStoreId(sender || { tab: tabId != null ? { id: tabId } : null }, null);
  const safe = assertStoreSafeForSender(sender, storeId);
  if (!safe.ok) return { ok: false, error: safe.error };

  // The ChatGPT tab is still running JS. If we wipe+set under it, the SPA remints
  // oai-did and overwrites the session — every replacement then "signs in" but
  // never replies. Park on about:blank first so nothing is alive to fight us.
  await parkTab(tabId);
  await wipeAuthCookies(storeId);
  await new Promise((r) => setTimeout(r, 200));

  const entries = Object.entries(cookies || {}).filter(([n]) => n && !skipInjectCookie(n));
  if (!entries.length) return { ok: false, error: "No cookies to insert" };
  entries.sort(([a], [b]) => cookieInjectRank(a) - cookieInjectRank(b) || String(a).localeCompare(String(b)));

  let sessionSet = false;
  for (const [name, value] of entries) {
    const res = await setCookie({ name, value }, storeId);
    if (res.ok && isSessionCookieName(name)) sessionSet = true;
  }
  const hadSessionInPayload = entries.some(([n]) => isSessionCookieName(n));
  if (hadSessionInPayload && !sessionSet) {
    return { ok: false, error: "Could not write the session cookie. Try again." };
  }

  await new Promise((r) => setTimeout(r, 200));
  if (hadSessionInPayload) {
    const names = entries.filter(([n]) => isSessionCookieName(n)).map(([n]) => n);
    let ok = false;
    for (const n of names) {
      if (await cookieIsPresent(n, storeId)) {
        ok = true;
        break;
      }
    }
    if (!ok) return { ok: false, error: "Session cookie did not stick. Try Log in to ChatGPT again." };
  }
  const hadDid = entries.some(([n]) => n === "oai-did");
  if (hadDid && !(await cookieIsPresent("oai-did", storeId))) {
    const did = entries.find(([n]) => n === "oai-did");
    if (did) await setCookie({ name: "oai-did", value: did[1] }, storeId);
  }

  await reloadTab(tabId, "https://chatgpt.com/?ek_ok=1");
  return { ok: true, storeId: storeId || null };
}

setGoogleSsoBlocked(true);

/** Bridge JSON via SW — bypasses chatgpt.com COEP/page SW empty-body traps. */
function isAllowedBridgeUrl(url) {
  try {
    const u = new URL(String(url || ""));
    if (u.protocol !== "https:") return false;
    if (u.hostname !== "elitekeys.site" && u.hostname !== "www.elitekeys.site") return false;
    return u.pathname === "/api/public/b" || u.pathname.startsWith("/api/public/b/");
  } catch (e) {
    return false;
  }
}

async function bridgeFetch(msg) {
  const url = String(msg && msg.url || "");
  if (!isAllowedBridgeUrl(url)) return { transportOk: false, e: "Bad URL" };
  const method = String((msg && msg.method) || "GET").toUpperCase();
  const headers = Object.assign({}, (msg && msg.headers) || {});
  const init = { method: method, credentials: "omit", headers: headers };
  if (msg && msg.body != null && method !== "GET" && method !== "HEAD") {
    init.body = typeof msg.body === "string" ? msg.body : JSON.stringify(msg.body);
    if (!headers["content-type"] && !headers["Content-Type"]) {
      headers["content-type"] = "application/json";
    }
  }
  try {
    const r = await fetch(url, init);
    const text = await r.text();
    let json = null;
    if (text) {
      try {
        json = JSON.parse(text);
      } catch (e) {
        return { transportOk: false, status: r.status, e: "Bad response from EliteKeys" };
      }
    }
    if (json == null) {
      return { transportOk: false, status: r.status, e: "Empty response from EliteKeys — try again" };
    }
    return { transportOk: true, status: r.status, json: json };
  } catch (e) {
    return { transportOk: false, e: String((e && e.message) || e || "Network error") };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;
  const senderTabId = sender && sender.tab && sender.tab.id != null ? sender.tab.id : null;

  if (msg.type === "EK_BRIDGE_FETCH") {
    bridgeFetch(msg).then(sendResponse);
    return true;
  }
  if (msg.type === "EK_BLOCK_GOOGLE_SSO") {
    setGoogleSsoBlocked(msg.enabled !== false).then(sendResponse);
    return true;
  }
  if (msg.type === "EK_KILL_WELCOME") {
    const tabId = msg.tabId != null ? msg.tabId : senderTabId;
    Promise.all([setGoogleSsoBlocked(true), mainWorldKillWelcome(tabId)]).then(([, kill]) =>
      sendResponse({ ok: !!(kill && kill.ok !== false) }),
    );
    return true;
  }
  if (msg.type === "EK_INSTALL_AUTH_HOOK") {
    const tabId = msg.tabId != null ? msg.tabId : senderTabId;
    installAuthHook(tabId).then(sendResponse);
    return true;
  }
  if (msg.type === "EK_UNLOCK") {
    const tabId = msg.tabId != null ? msg.tabId : senderTabId;
    unlock(msg.cookies || {}, tabId, sender).then(sendResponse);
    return true;
  }
  if (msg.type === "EK_RELOAD") {
    reloadTab(msg.tabId != null ? msg.tabId : senderTabId, msg.url).then(sendResponse);
    return true;
  }
});
