// EliteKeys ChatGPT v2 — on-page panel (chatgpt.com only).
// Renders a bottom-right "EliteKeys ChatGPT" button. Sign in with EliteKeys credentials,
// pick a Mix/Plus key, and unlock a working ChatGPT profile. All UI is built with DOM APIs
// and CSSOM styles (createElement + textContent + el.style only; no HTML-string assignment,
// no injected <style>) because chatgpt.com enforces Trusted Types and a strict CSP.
(function () {
  "use strict";
  if (window.__ek2Panel) return;
  window.__ek2Panel = { version: "2.0.27" };
  var EK2_PHONE = false;
  var EK2_VERSION = "2.0.27";
  var EK2_PLAT = "pc";

  var API = "https://elitekeys.site/api/public/b";
  var ACCENT = "#5ee9b5";
  var tok = null; // { t, username }
  var keys = [];
  var selected = null;
  var mounted = false;
  var swappedThisLoad = false;
  var extOutdated = false;
  var extNotice = "";
  var extVersionChecked = false;
  var extVersionPromise = null;

  /* ---------------------------------------------------------------- styling */
  function css(el, obj) {
    for (var k in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, k)) el.style.setProperty(k, obj[k]);
    }
    return el;
  }
  function mk(tag, styles, text) {
    var el = document.createElement(tag);
    if (styles) css(el, styles);
    if (text != null) el.textContent = text;
    return el;
  }

  /* ------------------------------------------------------------- bridge API */
  /** Prefer SW fetch so chatgpt.com COEP/page SW cannot empty the Response body. */
  function bridgeRequest(path, opts) {
    opts = opts || {};
    var url = API + path;
    var method = opts.method || "GET";
    var headers = opts.headers || {};
    var body = opts.body;
    return new Promise(function (resolve, reject) {
      function viaPage() {
        return fetch(url, {
          method: method,
          credentials: "omit",
          headers: headers,
          body: body,
        }).then(function (r) {
          return r.text().then(function (text) {
            if (!text) throw new Error("Empty response from EliteKeys — try again");
            try {
              return JSON.parse(text);
            } catch (e) {
              throw new Error("Bad response from EliteKeys — try again");
            }
          });
        });
      }
      try {
        chrome.runtime.sendMessage(
          {
            type: "EK_BRIDGE_FETCH",
            url: url,
            method: method,
            headers: headers,
            body: body != null ? body : null,
          },
          function (res) {
            if (chrome.runtime.lastError || !res) {
              viaPage().then(resolve, reject);
              return;
            }
            if (!res.transportOk) {
              reject(new Error(res.e || "Network error"));
              return;
            }
            resolve(res.json);
          },
        );
      } catch (e) {
        viaPage().then(resolve, reject);
      }
    });
  }
  function jsonPost(path, body) {
    return bridgeRequest(path, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body || {}),
    }).catch(function () {
      return { ok: false, e: "Network error" };
    });
  }
  function getNonce() {
    return bridgeRequest("/challenge", { method: "GET" }).then(function (j) {
      if (!j || !j.ok || !j.n) throw new Error("Session start failed — try again");
      return j.n;
    });
  }

  /* --------------------------------------------------------------- storage */
  function loadTok() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(["ek2_tok"], function (d) {
          resolve((d && d.ek2_tok) || null);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }
  function saveTok(v) {
    try {
      chrome.storage.local.set({ ek2_tok: v });
    } catch (e) {}
  }
  function clearTok() {
    try {
      chrome.storage.local.remove(["ek2_tok"]);
    } catch (e) {}
  }
  function saveLastKey(k) {
    try {
      chrome.storage.local.set({ ek2_last_key: k || null });
    } catch (e) {}
  }
  function saveLastCookies(cookies) {
    try {
      chrome.storage.local.set({ ek2_last_cookies: cookies || null });
    } catch (e) {}
  }
  function loadLastCookies() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(["ek2_last_cookies"], function (d) {
          resolve((d && d.ek2_last_cookies) || null);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }
  function loadLastKey() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(["ek2_last_key", "ek2_swap_at"], function (d) {
          resolve(d || {});
        });
      } catch (e) {
        resolve({});
      }
    });
  }

  /**
   * Auto-swap count lives in chrome.storage.local, not sessionStorage.
   * Unlock parks the tab on about:blank, which wipes chatgpt.com sessionStorage
   * and used to reset the cap — that is the refresh/account hop loop.
   */
  // Match /api/public/b/swap rate window (40/min). Keep hopping until a chat replies.
  var MAX_AUTO_SWAPS = 40;
  var MAX_RATE_RETRIES = 6;
  var RATE_RETRY_WAIT_MS = 6000;
  var AUTO_SWAP_TTL_MS = 30 * 60 * 1000;
  function getAutoSwaps() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(["ek2_auto_swaps", "ek2_auto_swaps_at"], function (d) {
          var at = Number((d && d.ek2_auto_swaps_at) || 0);
          if (at && Date.now() - at > AUTO_SWAP_TTL_MS) return resolve(0);
          resolve(Number((d && d.ek2_auto_swaps) || 0) || 0);
        });
      } catch (e) {
        resolve(0);
      }
    });
  }
  function setAutoSwaps(n) {
    try {
      chrome.storage.local.set({ ek2_auto_swaps: n, ek2_auto_swaps_at: Date.now() });
    } catch (e) {}
  }
  function resetAutoSwaps() {
    setAutoSwaps(0);
    setReinjected(false);
  }
  function bumpAutoSwaps() {
    return getAutoSwaps().then(function (n) {
      var next = n + 1;
      setAutoSwaps(next);
      return next;
    });
  }
  function getReinjected() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(["ek2_did_reinject"], function (d) {
          resolve(!!(d && Number(d.ek2_did_reinject)));
        });
      } catch (e) {
        resolve(false);
      }
    });
  }
  function setReinjected(v) {
    try {
      chrome.storage.local.set({ ek2_did_reinject: v ? 1 : 0 });
    } catch (e) {}
  }

  /** Session API says this is a real ChatGPT user (not the guest homepage). */
  function sessionLooksLive(u) {
    if (!u) return false;
    return !!u.ok;
  }

  /**
   * Guest header vs leftover marketing. A live login can still have a "Sign up"
   * CTA (Team / Business). That must not win over profile / chat chrome.
   */
  function decideLoginWall(s) {
    s = s || {};
    if (s.signedInChrome) return false;
    if (s.signUpForFree) return true;
    if (s.signUp && s.logIn) return true;
    return false;
  }

  /** Strong page signals beat a flaky session probe or a leftover Sign up link. */
  function decideSignedIn(s) {
    s = s || {};
    if (s.profile || s.userTurns || s.conversation || s.history) return true;
    if (s.sessionOk) return true;
    if (s.loginWall) return false;
    return false;
  }

  function versionTuple(v) {
    var m = String(v || "").match(/(\d+)\.(\d+)\.(\d+)/);
    if (!m) return null;
    return [Number(m[1]), Number(m[2]), Number(m[3])];
  }
  function versionAtLeast(v, min) {
    var a = versionTuple(v);
    var b = versionTuple(min);
    if (!a || !b) return false;
    var i = 0;
    for (i = 0; i < 3; i++) {
      if (a[i] > b[i]) return true;
      if (a[i] < b[i]) return false;
    }
    return true;
  }
  /** Missing server ext must not block the current extension. */
  function extensionNeedsUpdate(local, ext, plat) {
    var min = "";
    if (!ext || typeof ext.min !== "object" || !ext.min) return false;
    if (plat === "lemur" || plat === "orion" || plat === "pc") min = String(ext.min[plat] || "");
    if (!min) min = String(ext.min.pc || "");
    if (!min) return false;
    return !versionAtLeast(local, min);
  }

  /**
   * One unlock ladder for post-inject + auth-dead recover:
   *   sessionOk → ping (prove reply)
   *   else !reinjected → reinject once
   *   else → swap (soft-reset when at cap so the buyer is never stranded)
   * Composer alone is never "signed in" — guest Ask-anything must reinject/swap.
   */
  function decideHop(opts) {
    opts = opts || {};
    var swaps = Number(opts.autoSwaps || 0) || 0;
    var max = Number(opts.maxAutoSwaps || MAX_AUTO_SWAPS) || 40;
    if (opts.authDead) {
      return { action: swaps >= max ? "soft_reset_swap" : "swap", reason: "auth_dead" };
    }
    if (opts.sessionOk) return { action: "ping", reason: opts.loginWall ? "session_hydrating" : "session" };
    if (!opts.reinjected) return { action: "reinject", reason: opts.loginWall ? "login_wall" : "no_session" };
    if (swaps >= max) return { action: "soft_reset_swap", reason: "max_swaps" };
    return { action: "swap", reason: opts.loginWall ? "login_wall" : "no_session" };
  }

  /** @deprecated alias — tests and older call sites use decideAfterUnlock */
  function decideAfterUnlock(opts) {
    var d = decideHop(opts);
    if (d.action === "soft_reset_swap") return { action: "swap", reason: d.reason };
    return d;
  }

  /**
   * Overlay "I'm logged in" may dismiss when:
   *   - ChatGPT already answered the unlock ping, OR
   *   - the page already shows strong signed-in chrome (history / workspace / shell)
   *     and the buyer explicitly confirms — guest Ask-anything alone never skips.
   * Name-only frozen Go pages stay weak so they do not strand on a dead jar.
   */
  function canSkipOverlayToReady(opts) {
    opts = opts || {};
    if (String(opts.assistantText || "").trim().length > 1) return true;
    if (opts.loginWall) return false;
    return !!opts.strongSignedIn;
  }

  /** Pure keep/swap gate used by proveChatWorks (and offline proofs). */
  function decideUnlockKeep(r, signedIn, strongSignedIn) {
    if (r && r.ok && String(r.text || "").trim().length > 1) return "ready";
    if (!signedIn || (r && /login_wall/i.test(String(r.reason || "")))) return "swap";
    // Strong login chrome sticks even if the OK ping timed out / send flaked.
    // Weak signed-in (name-only frozen Go) still hops until a real reply.
    if (strongSignedIn) return "ready";
    return "swap";
  }

  /** Keep hopping on transient unlock failures; stop only on auth/stock/terminal codes. */
  function shouldKeepHoppingUnlockError(err) {
    var e = String(err || "");
    if (!e) return true;
    if (/sign in/i.test(e)) return false;
    if (/outdated|redeem your key again/i.test(e)) return false;
    if (/not valid|revoked|invalid (code|key)/i.test(e)) return false;
    if (/no accounts available|out of stock|no chatgpt accounts/i.test(e)) return false;
    return true;
  }

  /**
   * EK_UNLOCK parks the tab (about:blank) then reloads chatgpt.com. That closes
   * the content-script message port. Treat port-closed / invalidated-context as
   * "inject in progress" — NOT a failed insert — or iOS hops accounts forever.
   */
  function isUnlockNavigationError(err) {
    var e = String(err || "");
    return /port closed|receiving end does not exist|message port closed|context invalidated|extension context invalidated|asynchronous response/i.test(
      e,
    );
  }

  /** Bump the hop counter, then swap. Direct doUnlock(true) without a bump loops forever. */
  function hopAfterUnlockFailure(btn, overlayMsg, statusMsg) {
    return bumpAutoSwaps().then(function (swaps) {
      if (swaps > MAX_AUTO_SWAPS) {
        if (pageLooksSignedIn() || pageHasStrongSignedInChrome()) {
          hideTestOverlay();
          markUnlockReady();
          return false;
        }
        if (btn) btn.disabled = false;
        hideTestOverlay();
        setStatus(statusMsg || "Could not unlock a working account. Try Log in to ChatGPT again.", "err");
        return false;
      }
      showTestOverlay(overlayMsg || "Trying another working ChatGPT account…");
      setStatus(statusMsg || "Hopping to another account…", "ok");
      setTimeout(function () {
        doUnlock(btn, true, true);
      }, 900);
      return true;
    });
  }

  function bg(msg) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage(msg, function (r) {
          var err = chrome.runtime.lastError && chrome.runtime.lastError.message;
          if (r) return resolve(r);
          resolve({ ok: false, error: err || "No response from extension background" });
        });
      } catch (e) {
        resolve({ ok: false, error: String(e && e.message ? e.message : e) });
      }
    });
  }

  /* ------------------------------------------------------------------- DOM */
  var fab, panel, body, statusEl;

  function setStatus(text, kind) {
    if (!statusEl) return;
    statusEl.textContent = text || "";
    statusEl.style.setProperty(
      "color",
      kind === "err" ? "#ffb4b4" : kind === "ok" ? ACCENT : "rgba(232,255,245,.8)",
    );
  }

  function clearBody() {
    while (body && body.firstChild) body.removeChild(body.firstChild);
  }

  function primaryBtn(label) {
    return mk(
      "button",
      {
        width: "100%",
        border: "0",
        "border-radius": "12px",
        padding: "12px 14px",
        margin: "4px 0 0",
        font: "800 13px/1.2 system-ui,sans-serif",
        cursor: "pointer",
        background: "linear-gradient(135deg,#5ee9b5,#2f9e74)",
        color: "#04140f",
      },
      label,
    );
  }
  function ghostBtn(label) {
    return mk(
      "button",
      {
        width: "100%",
        "border-radius": "10px",
        padding: "9px 12px",
        margin: "8px 0 0",
        font: "700 12px/1.2 system-ui,sans-serif",
        cursor: "pointer",
        background: "rgba(255,255,255,.06)",
        color: "#e8fff5",
        border: "1px solid rgba(94,233,181,.22)",
      },
      label,
    );
  }
  function field(labelText, type) {
    var wrap = mk("label", { display: "block", margin: "0 0 9px" });
    var lab = mk(
      "span",
      {
        display: "block",
        "font-size": "10px",
        "font-weight": "700",
        "letter-spacing": ".12em",
        "text-transform": "uppercase",
        color: "rgba(232,255,245,.6)",
        "margin-bottom": "4px",
      },
      labelText,
    );
    var input = mk("input", {
      width: "100%",
      "box-sizing": "border-box",
      "border-radius": "10px",
      padding: "10px 12px",
      font: "600 13px/1.2 system-ui,sans-serif",
      color: "#eafff7",
      background: "rgba(0,0,0,.28)",
      border: "1px solid rgba(94,233,181,.2)",
      outline: "none",
    });
    input.type = type || "text";
    input.autocomplete = type === "password" ? "current-password" : "username";
    wrap.appendChild(lab);
    wrap.appendChild(input);
    return { wrap: wrap, input: input };
  }

  /* ----------------------------------------------------------- login view */
  function renderLogin(prefillErr) {
    clearBody();
    var intro = mk(
      "p",
      { margin: "0 0 12px", "font-size": "12px", color: "rgba(232,255,245,.82)", "line-height": "1.5" },
      "Sign in with your EliteKeys account (your elitekeys.site username and password — never your Gmail).",
    );
    var u = field("EliteKeys username", "text");
    var p = field("EliteKeys password", "password");
    var signIn = primaryBtn("Sign in");

    function submit() {
      var username = (u.input.value || "").trim();
      var password = p.input.value || "";
      if (!username || !password) {
        setStatus("Enter your username and password.", "err");
        return;
      }
      signIn.disabled = true;
      setStatus("Signing in…");
      getNonce()
        .then(function (n) {
          return jsonPost("/login", { u: username, p: password, n: n });
        })
        .then(function (res) {
          signIn.disabled = false;
          if (!res || !res.ok || !res.t) {
            setStatus((res && res.e) || "Sign-in failed.", "err");
            return;
          }
          tok = { t: res.t, username: res.username || username };
          saveTok(tok);
          setStatus("Signed in.", "ok");
          renderKeys();
          loadKeys();
        })
        .catch(function (e) {
          signIn.disabled = false;
          setStatus(String((e && e.message) || "Sign-in failed."), "err");
        });
    }

    signIn.addEventListener("click", submit);
    p.input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") submit();
    });

    body.appendChild(intro);
    body.appendChild(u.wrap);
    body.appendChild(p.wrap);
    body.appendChild(signIn);
    if (prefillErr) setStatus(prefillErr, "err");
  }

  /* ------------------------------------------------------------ keys view */
  function planLabel(k) {
    return k.key_type === "plus" ? "Plus" : "Mix";
  }
  function keyRow(k) {
    var isSel = selected && selected.key_text === k.key_text;
    var row = mk("button", {
      display: "flex",
      "align-items": "center",
      gap: "10px",
      width: "100%",
      "text-align": "left",
      "border-radius": "11px",
      padding: "10px 11px",
      margin: "0 0 7px",
      cursor: "pointer",
      background: isSel ? "rgba(94,233,181,.14)" : "rgba(255,255,255,.03)",
      border: isSel ? "1px solid rgba(94,233,181,.55)" : "1px solid rgba(255,255,255,.07)",
    });
    var badge = mk(
      "span",
      {
        flex: "0 0 auto",
        "border-radius": "7px",
        padding: "3px 8px",
        font: "800 10px/1.2 system-ui,sans-serif",
        "letter-spacing": ".06em",
        "text-transform": "uppercase",
        background: k.key_type === "plus" ? "rgba(147,197,253,.18)" : "rgba(94,233,181,.16)",
        color: k.key_type === "plus" ? "#bfdbfe" : ACCENT,
      },
      planLabel(k),
    );
    var mid = mk("span", { "min-width": "0", flex: "1 1 auto" });
    var code = mk(
      "span",
      {
        display: "block",
        font: "700 12px/1.3 ui-monospace,monospace",
        color: "#eafff7",
        "white-space": "nowrap",
        overflow: "hidden",
        "text-overflow": "ellipsis",
      },
      k.key_text,
    );
    var sub = mk(
      "span",
      { display: "block", "font-size": "10px", color: "rgba(232,255,245,.55)" },
      k.status === "used" ? "Active — click to re-open" : "Ready to activate",
    );
    mid.appendChild(code);
    mid.appendChild(sub);
    var tick = mk("span", { flex: "0 0 auto", color: ACCENT, font: "800 13px/1 system-ui" }, isSel ? "✓" : "");
    row.appendChild(badge);
    row.appendChild(mid);
    row.appendChild(tick);
    row.addEventListener("click", function () {
      selected = k;
      renderKeys();
      if (!tok) return;
      // Mid-test taps used to restart Unlock (reload loop) because the panel
      // sat above the test overlay. Wait out the proof instead.
      if (ssNum("ek2_testing")) {
        setStatus("Already testing this ChatGPT account — wait for the overlay.", "ok");
        togglePanel(false);
        return;
      }
      if (ssNum("ek2_ready") && k.status === "used") {
        togglePanel(false);
        setStatus("This key is already active. You can chat now.", "ok");
        return;
      }
      doUnlock(null, false);
    });
    return row;
  }

  function renderKeys() {
    clearBody();
    var head = mk("div", { display: "flex", "align-items": "center", gap: "8px", margin: "0 0 10px" });
    var who = mk(
      "span",
      { "font-size": "12px", color: "rgba(232,255,245,.8)" },
      "Signed in as ",
    );
    var name = mk("b", { color: "#eafff7" }, (tok && tok.username) || "");
    who.appendChild(name);
    var out = mk(
      "button",
      {
        "margin-left": "auto",
        background: "transparent",
        border: "0",
        color: "rgba(232,255,245,.55)",
        cursor: "pointer",
        font: "700 11px/1 system-ui",
        "text-decoration": "underline",
      },
      "Sign out",
    );
    out.addEventListener("click", function () {
      tok = null;
      selected = null;
      keys = [];
      clearTok();
      setStatus("");
      renderLogin();
    });
    head.appendChild(who);
    head.appendChild(out);
    body.appendChild(head);

    var list = mk("div", { "max-height": "230px", "overflow-y": "auto", margin: "0 0 4px" });
    list.id = "ek2-keylist";
    body.appendChild(list);

    if (!keys.length) {
      list.appendChild(
        mk(
          "p",
          { margin: "6px 2px", "font-size": "12px", color: "rgba(232,255,245,.6)", "line-height": "1.5" },
          "No Mix / Plus keys on this account yet. Redeem a ChatGPT key on elitekeys.site, then reopen this panel.",
        ),
      );
    } else {
      keys.forEach(function (k) {
        list.appendChild(keyRow(k));
      });
    }

    var go = primaryBtn("Log in to ChatGPT");
    go.disabled = !selected;
    if (!selected) go.style.setProperty("opacity", "0.5");
    go.addEventListener("click", function () {
      if (!selected) {
        setStatus("Pick a key first.", "err");
        return;
      }
      doUnlock(go, false);
    });
    body.appendChild(go);

    var refresh = ghostBtn("Refresh my keys");
    refresh.addEventListener("click", function () {
      loadKeys();
    });
    body.appendChild(refresh);
  }

  function loadKeys() {
    if (!tok) {
      renderLogin();
      return;
    }
    setStatus("Loading your keys…");
    getNonce()
      .then(function (n) {
        return jsonPost("/keys", { n: n, t: tok.t });
      })
      .then(function (res) {
        if (!res || !res.ok) {
          if (res && /sign in/i.test(res.e || "")) {
            tok = null;
            clearTok();
            renderLogin("Your session expired — sign in again.");
            return;
          }
          setStatus((res && res.e) || "Could not load keys.", "err");
          return;
        }
        keys = (res.keys || []).map(function (k) {
          return {
            key_text: k.key_text,
            key_type: k.key_type,
            status: k.status,
          };
        });
        if (selected) {
          var still = keys.filter(function (k) {
            return k.key_text === selected.key_text;
          })[0];
          selected = still || null;
        }
        setStatus(keys.length ? "" : "No keys found on this account yet.");
        renderKeys();
      })
      .catch(function (e) {
        setStatus(String((e && e.message) || "Could not load keys."), "err");
      });
  }

  function sessionAccessUsable(s) {
    if (!s || !s.user) return { ok: false, reason: "no_user" };
    var err = s.error != null ? String(s.error) : "";
    if (/RefreshAccessTokenError|AccessTokenError|OAuthCallback/i.test(err)) {
      return { ok: false, reason: "refresh_error:" + err };
    }
    var at = s.accessToken != null ? String(s.accessToken) : "";
    if (!at) return { ok: false, reason: "no_access_token" };
    try {
      var parts = at.split(".");
      if (parts.length >= 2) {
        var b64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
        while (b64.length % 4) b64 += "=";
        var payload = JSON.parse(atob(b64));
        if (payload && typeof payload.exp === "number" && payload.exp * 1000 < Date.now() - 15000) {
          return { ok: false, reason: "access_token_jwt_expired" };
        }
      }
    } catch (eJwt) {}
    return { ok: true, reason: "ok" };
  }

  /**
   * /backend-api/models must list at least one GPT-capable model. Empty or
   * noauth here is "signed in but cannot use ChatGPT".
   */
  function modelsLookUsable(body) {
    var text = String(body || "").trim();
    if (!text) return { ok: false, reason: "no_models" };
    try {
      var j = JSON.parse(text);
      var raw = j && (j.models || j.data || j.items);
      var list = Array.isArray(raw) ? raw : raw && Array.isArray(raw.data) ? raw.data : [];
      if (!list.length) return { ok: false, reason: "no_models" };
      for (var i = 0; i < list.length; i++) {
        var m = list[i];
        var slug =
          typeof m === "string"
            ? m
            : String((m && (m.slug || m.id || m.title || m.name)) || "");
        if (/gpt|o1|o3|o4|chatgpt|auto/i.test(slug)) return { ok: true, reason: "ok" };
      }
      return { ok: false, reason: "no_gpt_models" };
    } catch (e) {
      return { ok: false, reason: "models_parse" };
    }
  }

  /**
   * After cookie inject we must not call the buyer "logged in" until session,
   * /me, Sentinel, and /models all say this account can actually use GPT.
   * modelsStatus omitted = skip (older probe); when present, empty/401 fails closed.
   */
  function interpretAuthProbe(p) {
    p = p || {};
    if (p.cf) return { ok: false, retry: true, reason: "cloudflare" };
    if (p.sessionStatus === 401 || p.sessionStatus === 403) {
      if (p.sessionJson) return { ok: false, retry: false, reason: "session_" + p.sessionStatus };
      return { ok: false, retry: true, reason: "cloudflare" };
    }
    var usable = sessionAccessUsable(p.session);
    if (!usable.ok) return { ok: false, retry: false, reason: usable.reason };
    if (p.meStatus === 401 || (p.meStatus === 403 && p.meJson)) {
      return { ok: false, retry: false, reason: "me_" + p.meStatus };
    }
    if (p.senStatus === 401 || (p.senStatus === 403 && p.senJson)) {
      return { ok: false, retry: false, reason: "sentinel_" + p.senStatus };
    }
    var blob = String(p.meBody || "") + String(p.senBody || "") + String(p.modelsBody || "");
    if (/chatgpt-noauth|chatgpt-loggedout|"force_login"\s*:\s*true/i.test(blob)) {
      return { ok: false, retry: false, reason: "noauth" };
    }
    if (p.modelsStatus === 401 || (p.modelsStatus === 403 && p.modelsJson)) {
      return { ok: false, retry: false, reason: "models_" + p.modelsStatus };
    }
    if (p.modelsStatus === 403 && !p.modelsJson) {
      return { ok: false, retry: true, reason: "cloudflare" };
    }
    if (p.modelsStatus == null || p.modelsStatus === 0) {
      // Same bar as the TG checker: session + /me is not enough to call it working.
      if (p.meStatus != null) return { ok: false, retry: true, reason: "proof_incomplete" };
    } else {
      var models = modelsLookUsable(p.modelsBody);
      if (!models.ok) {
        // HTML / parse glitch is a retry, not a dead account (TG checker "soft").
        if (models.reason === "models_parse" || !p.modelsJson) {
          return { ok: false, retry: true, reason: "models_parse" };
        }
        return { ok: false, retry: false, reason: models.reason };
      }
    }
    return { ok: true, reason: "ok" };
  }

  /**
   * Pure unlock-gate: retry CF, swap a proven-dead cookie, ping only when
   * APIs say the account has GPT access (or CF exhausted and the page may work).
   */
  function decideUnlockTest(u, tries, cfg) {
    cfg = cfg || {};
    var maxRetry = cfg.maxRetry || 6;
    u = u || {};
    if (u.ok) return { action: "ping", reason: u.reason || "ok" };
    if (!u.retry) return { action: "swap", reason: u.reason || "dead" };
    if (tries < maxRetry) return { action: "retry" };
    return { action: "ping", reason: "probe_retry_exhausted" };
  }

  function probeChatCapable() {
    return fetch("https://chatgpt.com/api/auth/session", {
      credentials: "include",
      cache: "no-store",
    })
      .then(function (r) {
        var ct = String(r.headers.get("content-type") || "");
        var jsonish = ct.indexOf("json") >= 0;
        return r.text().then(function (text) {
          var session = null;
          try {
            session = JSON.parse(text);
          } catch (e) {}
          return {
            sessionStatus: r.status,
            sessionJson: jsonish && !!session,
            session: session,
            cf: r.status === 403 && !jsonish,
          };
        });
      })
      .then(function (base) {
        var usable = sessionAccessUsable(base.session);
        if (base.cf || !usable.ok || !base.session || !base.session.accessToken) {
          return interpretAuthProbe(base);
        }
        var headers = {
          Authorization: "Bearer " + String(base.session.accessToken),
          Accept: "application/json",
        };
        return fetch("https://chatgpt.com/backend-api/me", {
          credentials: "include",
          cache: "no-store",
          headers: headers,
        }).then(function (me) {
          var meCt = String(me.headers.get("content-type") || "");
          return me.text().then(function (meBody) {
            function withModels(extra) {
              return fetch("https://chatgpt.com/backend-api/models", {
                credentials: "include",
                cache: "no-store",
                headers: headers,
              })
                .then(function (mod) {
                  var modCt = String(mod.headers.get("content-type") || "");
                  return mod.text().then(function (modBody) {
                    return interpretAuthProbe(
                      Object.assign({}, base, extra, {
                        modelsStatus: mod.status,
                        modelsJson: modCt.indexOf("json") >= 0,
                        modelsBody: modBody,
                      }),
                    );
                  });
                })
                .catch(function () {
                  return { ok: false, retry: true, reason: "models_failed" };
                });
            }
            return fetch("https://chatgpt.com/backend-api/sentinel/chat-requirements", {
              method: "POST",
              credentials: "include",
              cache: "no-store",
              headers: Object.assign({ "Content-Type": "application/json" }, headers),
              body: "{}",
            })
              .then(function (sen) {
                var senCt = String(sen.headers.get("content-type") || "");
                return sen.text().then(function (senBody) {
                  return withModels({
                    meStatus: me.status,
                    meJson: meCt.indexOf("json") >= 0,
                    meBody: meBody,
                    senStatus: sen.status,
                    senJson: senCt.indexOf("json") >= 0,
                    senBody: senBody,
                  });
                });
              })
              .catch(function () {
                return withModels({
                  meStatus: me.status,
                  meJson: meCt.indexOf("json") >= 0,
                  meBody: meBody,
                });
              });
          });
        });
      })
      .catch(function () {
        return { ok: false, retry: true, reason: "probe_failed" };
      });
  }

  function probeChatgptSession() {
    return fetch("https://chatgpt.com/api/auth/session", {
      credentials: "include",
      cache: "no-store",
    })
      .then(function (r) {
        return r.json().catch(function () {
          return null;
        });
      })
      .then(function (s) {
        return sessionAccessUsable(s);
      })
      .catch(function () {
        return { ok: false, reason: "probe_failed" };
      });
  }

  function isDeadChatgptSession(u) {
    var r = String((u && u.reason) || "");
    return /refresh_error|no_access_token|access_token_jwt_expired|me_401|me_403|sentinel_401|noauth|session_401|models_401|models_403|no_models|no_gpt_models/.test(
      r,
    );
  }

  function looksExpiredPage() {
    try {
      var dialogs = document.querySelectorAll("div[role='dialog'],dialog,[aria-modal='true']");
      for (var i = 0; i < dialogs.length; i++) {
        var el = dialogs[i];
        if (!el) continue;
        try {
          if (el.getAttribute && el.getAttribute("data-ek2-hidden") === "1") continue;
        } catch (eH) {}
        try {
          var st = window.getComputedStyle ? window.getComputedStyle(el) : null;
          if (st && (st.display === "none" || st.visibility === "hidden" || st.opacity === "0")) continue;
        } catch (eS) {}
        var t = String(el.textContent || "");
        if (/your session has expired/i.test(t) && /log in/i.test(t)) return true;
        if (/session expired/i.test(t) && /continue using the app/i.test(t)) return true;
      }
    } catch (e1) {}
    return false;
  }

  function pingKillExpired() {
    try {
      if (window.__ek2WelcomeBlock && typeof window.__ek2WelcomeBlock.killExpired === "function") {
        window.__ek2WelcomeBlock.killExpired();
      }
    } catch (eK) {}
    try {
      chrome.runtime.sendMessage({ type: "EK_KILL_WELCOME" }, function () {
        void chrome.runtime.lastError;
      });
    } catch (eB) {}
  }

  function rateRetryCount() {
    return ssNum("ek2_rate_retries") || 0;
  }
  function bumpRateRetries() {
    var n = rateRetryCount() + 1;
    ssSet("ek2_rate_retries", n);
    return n;
  }
  function resetRateRetries() {
    ssSet("ek2_rate_retries", 0);
  }

  /** Redeem/bind the selected key and insert the account cookies. */
  function doUnlock(btn, isSwap, fromRateRetry) {
    if (extOutdated) {
      setStatus(extNotice || "This extension is outdated. Redeem your key again at https://elitekeys.site/ and download the new extension.", "err");
      try {
        if (panel) panel.style.setProperty("display", "block");
        renderOutdated();
      } catch (eOut) {}
      return;
    }
    if (!tok || !selected) return;
    // Manual Log in / key tap must not restart Unlock while the reply proof
    // (or a hop) is already running — that was the phone refresh loop.
    if (!isSwap && !fromRateRetry && ssNum("ek2_testing")) {
      setStatus("Already testing this ChatGPT account — wait for the overlay.", "ok");
      try {
        togglePanel(false);
      } catch (eT) {}
      return;
    }
    if (!isSwap && !fromRateRetry) {
      resetAutoSwaps();
      resetRateRetries();
    } else setReinjected(false);
    if (btn) btn.disabled = true;
    saveLastKey(selected);
    setStatus(isSwap ? "Getting a fresh working account…" : "Activating your account…");
    getNonce()
      .then(function (n) {
        var burnBound = !!ssNum("ek2_bound_dead");
        return jsonPost(isSwap || burnBound ? "/swap" : "/u", {
          k: selected.key_text,
          n: n,
          t: tok.t,
          cv: EK2_VERSION,
          plat: EK2_PLAT,
          // Only proven-dead JWTs burn the bound cookie. A hop (login wall /
          // send flake) parks it back into stock so Unlock cannot empty the pool.
          dead: burnBound,
        });
      })
      .then(function (res) {
        if (!res || !res.ok || !res.cookies) {
          if (res && /too many attempts/i.test(res.e || "")) {
            var n = bumpRateRetries();
            if (n <= MAX_RATE_RETRIES) {
              showTestOverlay("Stock is busy — waiting a few seconds, then getting you a working account…");
              setStatus("Waiting a few seconds, then trying another working account…", "ok");
              setTimeout(function () {
                doUnlock(btn, isSwap, true);
              }, RATE_RETRY_WAIT_MS);
              return;
            }
          }
          var errMsg = (res && res.e) || "Could not activate this key.";
          if (res && (res.outdated || /outdated|redeem your key again/i.test(errMsg))) {
            extOutdated = true;
            extNotice = errMsg;
            if (btn) btn.disabled = false;
            try { hideTestOverlay(); } catch (eHide) {}
            try { if (panel) panel.style.setProperty("display", "block"); } catch (ePan) {}
            try { renderOutdated(); } catch (eRen) {}
            setStatus(errMsg, "err");
            return;
          }
          if (res && /sign in/i.test(res.e || "")) {
            if (btn) btn.disabled = false;
            hideTestOverlay();
            tok = null;
            clearTok();
            renderLogin("Your EliteKeys login expired — sign in again.");
            return;
          }
          // Transient / empty stock races: keep hopping — never strand the buyer mid-unlock.
          // Always bump the counter; doUnlock(true) alone never advances it and loops forever.
          if (shouldKeepHoppingUnlockError(errMsg) && tok && selected) {
            hopAfterUnlockFailure(btn, "Trying another working ChatGPT account…", "Activation missed — hopping to another account…");
            return;
          }
          if (btn) btn.disabled = false;
          hideTestOverlay();
          setStatus(errMsg, "err");
          return;
        }
        resetRateRetries();
        setStatus("Inserting the ChatGPT account…", "ok");
        saveLastCookies(res.cookies);
        try {
          sessionStorage.setItem("ek2_ready", "0");
          sessionStorage.setItem("ek2_testing", "1");
        } catch (eR) {}
        bg({ type: "EK_UNLOCK", cookies: res.cookies }).then(function (r) {
          if (!r || !r.ok) {
            var injErr = (r && r.error) || "Could not insert the account.";
            // Orion parks to about:blank during inject — port closes. That is success-in-progress.
            if (isUnlockNavigationError(injErr)) return;
            if (tok && selected) {
              hopAfterUnlockFailure(
                btn,
                "Cookie insert failed — trying another account…",
                "Insert failed — hopping to another account…",
              );
              return;
            }
            if (btn) btn.disabled = false;
            hideTestOverlay();
            setStatus(injErr + " Try again.", "err");
            return;
          }
          // Page will navigate/reload; nothing more to do.
        });
      })
      .catch(function (e) {
        var msg = String((e && e.message) || "Activation failed.");
        if (isUnlockNavigationError(msg)) return;
        if (shouldKeepHoppingUnlockError(msg) && tok && selected) {
          hopAfterUnlockFailure(btn, "Network glitch — trying another account…", "Network glitch — hopping to another account…");
          return;
        }
        if (btn) btn.disabled = false;
        setStatus(msg, "err");
      });
  }

  var UNLOCK_TEST = {
    maxRetry: 8,
    minTries: 4,
    composerWaitMs: 10000,
    loadWaitMs: 3000,
    replyWaitMs: 12000,
    pingText: "Reply with the single word OK.",
    maxSwaps: 40,
  };

  function showTestOverlay(msg) {
    // Panel must stay closed so Log in / Active cannot restart Unlock.
    // Backdrop MUST use pointer-events:none so the ChatGPT composer under the
    // dim layer still receives the unlock ping (type + send). Only the card
    // itself is clickable — otherwise phone packs loop on "Still signed out".
    try {
      if (panel) togglePanel(false);
    } catch (eP) {}
    var el = document.getElementById("ek2-test-overlay");
    if (!el) {
      el = mk("div", {
        position: "fixed",
        inset: "0",
        // Above the EliteKeys panel (3646) so Log in / Active cannot cover the proof.
        "z-index": "2147483647",
        display: "flex",
        "align-items": "center",
        "justify-content": "center",
        background: "rgba(4, 20, 15, 0.78)",
        color: "#e8fff5",
        font: "600 15px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif",
        "text-align": "center",
        padding: "24px",
        "pointer-events": "none",
      });
      el.id = "ek2-test-overlay";
      var inner = mk("div", {
        "max-width": "420px",
        background: "linear-gradient(165deg,#0d221b,#071310)",
        border: "1px solid rgba(94,233,181,.28)",
        "border-radius": "16px",
        padding: "22px 20px",
        "box-shadow": "0 18px 50px rgba(0,0,0,.45)",
        "pointer-events": "auto",
      });
      inner.appendChild(
        mk("div", { font: "800 16px/1.3 system-ui", "margin-bottom": "8px" }, "Testing this ChatGPT account"),
      );
      var body = mk(
        "div",
        { "font-size": "13px", opacity: ".88" },
        msg || "Checking GPT access and waiting for a real reply…",
      );
      body.id = "ek2-test-overlay-msg";
      inner.appendChild(body);
      var skip = mk(
        "button",
        {
          margin: "14px auto 0",
          display: "block",
          border: "1px solid rgba(94,233,181,.35)",
          background: "rgba(94,233,181,.12)",
          color: "#e8fff5",
          "border-radius": "10px",
          padding: "10px 14px",
          font: "700 13px/1.2 system-ui,sans-serif",
          cursor: "pointer",
        },
        "I'm logged in — use ChatGPT",
      );
      skip.id = "ek2-test-overlay-skip";
      skip.addEventListener("click", function (ev) {
        try {
          ev.preventDefault();
          ev.stopPropagation();
        } catch (eS) {}
        // Stick when ChatGPT already replied OR the buyer confirms a real login.
        // Do NOT re-run proveChatWorks here — that restarted the hop/refresh loop.
        if (
          canSkipOverlayToReady({
            assistantText: currentAssistantText(),
            strongSignedIn: pageHasStrongSignedInChrome() || pageLooksSignedIn(),
            loginWall: pageHasLoginWall() && !pageHasSignedInChrome(),
          })
        ) {
          markUnlockReady();
          return;
        }
        showTestOverlay("Still on ChatGPT's Log in page — waiting for a real signed-in account…");
      });
      inner.appendChild(skip);
      el.appendChild(inner);
      try {
        document.documentElement.appendChild(el);
      } catch (eO) {}
    } else {
      el.style.setProperty("display", "flex");
      var m = document.getElementById("ek2-test-overlay-msg");
      if (m && msg) m.textContent = msg;
    }
    ssSet("ek2_testing", 1);
  }

  function hideTestOverlay() {
    var el = document.getElementById("ek2-test-overlay");
    if (el) el.style.setProperty("display", "none");
    ssSet("ek2_testing", 0);
  }

  function markUnlockReady() {
    ssSet("ek2_ready", 1);
    ssSet("ek2_bound_dead", 0);
    ssSet("ek2_testing", 0);
    hideTestOverlay();
    pingKillExpired();
    try {
      var u = new URL(location.href);
      if (u.searchParams.has("ek_ok")) {
        u.searchParams.delete("ek_ok");
        history.replaceState({}, "", u.pathname + u.search + u.hash);
      }
    } catch (eU) {}
    togglePanel(true);
    setStatus("This ChatGPT account is working. You can chat now.", "ok");
  }

  function waitForComposer(timeoutMs) {
    return new Promise(function (resolve) {
      var t0 = Date.now();
      function tick() {
        if (composerPresent()) return resolve(true);
        if (Date.now() - t0 > timeoutMs) return resolve(false);
        setTimeout(tick, 400);
      }
      tick();
    });
  }

  function sleep(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  function isVisibleEl(el) {
    try {
      if (!el || isEk2Ui(el)) return false;
      var st = window.getComputedStyle(el);
      if (!st || st.display === "none" || st.visibility === "hidden" || Number(st.opacity) === 0) return false;
      var r = el.getBoundingClientRect();
      return r.width > 8 && r.height > 8;
    } catch (eV) {
      return false;
    }
  }

  function findComposer() {
    var sels = [
      "div.ProseMirror[contenteditable='true']",
      "#prompt-textarea [contenteditable='true']",
      "[data-testid='composer'] [contenteditable='true']",
      "[contenteditable='true'].ProseMirror",
      "#prompt-textarea",
      "textarea[name='prompt-textarea']",
      "textarea#prompt-textarea",
      "#prompt-textarea textarea",
      "[data-testid='composer'] textarea",
    ];
    var hidden = null;
    for (var i = 0; i < sels.length; i++) {
      var nodes = document.querySelectorAll(sels[i]);
      for (var j = 0; j < nodes.length; j++) {
        var el = nodes[j];
        if (!el || isEk2Ui(el)) continue;
        var tag = String(el.tagName || "").toUpperCase();
        var target = el;
        if (tag !== "TEXTAREA" && tag !== "INPUT" && !el.isContentEditable && el.getAttribute("contenteditable") !== "true") {
          var inner = el.querySelector("textarea, [contenteditable='true']");
          if (inner) target = inner;
          else continue;
        }
        if (isVisibleEl(target)) return target;
        if (!hidden) hidden = target;
      }
    }
    return hidden;
  }

  function composerPlainText() {
    var el = findComposer();
    if (!el) return "";
    return String(el.value || el.innerText || el.textContent || "")
      .replace(/\u200B/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function composerHasText(expect) {
    var got = composerPlainText();
    if (!got) return false;
    if (/^ask anything$/i.test(got) || /^message$/i.test(got)) return false;
    if (!expect) return got.length > 1;
    var needle = String(expect).replace(/\s+/g, " ").trim().slice(0, 10);
    return got.indexOf(needle) >= 0 || got.length >= 2;
  }

  function placeCaret(el) {
    try {
      el.focus();
    } catch (eF) {}
    try {
      var range = document.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (eR) {}
  }

  /** Type the test prompt into the visible ProseMirror / textarea. Does not send. */
  function typePing(text) {
    var el = findComposer();
    if (!el) return false;
    placeCaret(el);
    var tag = String(el.tagName || "").toUpperCase();
    if (tag === "TEXTAREA" || tag === "INPUT") {
      try {
        var proto = tag === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        var desc = Object.getOwnPropertyDescriptor(proto, "value");
        if (desc && desc.set) desc.set.call(el, text);
        else el.value = text;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } catch (eV) {
        return false;
      }
      return composerHasText(text);
    }
    try {
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, text);
    } catch (eI) {}
    if (composerHasText(text)) return true;
    try {
      var dt = new DataTransfer();
      dt.setData("text/plain", text);
      el.dispatchEvent(new ClipboardEvent("paste", { bubbles: true, cancelable: true, clipboardData: dt }));
    } catch (eP) {}
    if (composerHasText(text)) return true;
    try {
      placeCaret(el);
      el.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, data: text, inputType: "insertText" }));
      document.execCommand("insertText", false, text);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" }));
    } catch (eT) {}
    return composerHasText(text);
  }

  function findSendCandidates() {
    var sels = [
      "[data-testid='send-button']",
      "button[data-testid='fruitjuice-send-button']",
      "button[aria-label='Send prompt']",
      "button[aria-label='Send message']",
      "button[aria-label='Send']",
      "#composer-submit-button",
    ];
    var out = [];
    for (var i = 0; i < sels.length; i++) {
      var nodes = document.querySelectorAll(sels[i]);
      for (var j = 0; j < nodes.length; j++) {
        var btn = nodes[j];
        if (!btn || isEk2Ui(btn)) continue;
        if (out.indexOf(btn) < 0) out.push(btn);
      }
    }
    try {
      var composer = findComposer();
      var form = composer && composer.closest ? composer.closest("form") : null;
      if (form) {
        var submits = form.querySelectorAll("button[type='submit'], button");
        for (var s = 0; s < submits.length; s++) {
          if (isEk2Ui(submits[s])) continue;
          if (out.indexOf(submits[s]) < 0) out.push(submits[s]);
        }
      }
    } catch (eF) {}
    return out;
  }

  function sendButtonEnabled() {
    var nodes = findSendCandidates();
    for (var i = 0; i < nodes.length; i++) {
      var btn = nodes[i];
      if (btn.disabled || btn.getAttribute("aria-disabled") === "true") continue;
      if (btn.getAttribute("data-disabled") === "true") continue;
      return btn;
    }
    return null;
  }

  function pressButton(btn) {
    if (!btn) return false;
    try {
      var opts = { bubbles: true, cancelable: true, view: window, buttons: 1 };
      btn.dispatchEvent(new PointerEvent("pointerdown", opts));
      btn.dispatchEvent(new MouseEvent("mousedown", opts));
      btn.dispatchEvent(new PointerEvent("pointerup", opts));
      btn.dispatchEvent(new MouseEvent("mouseup", opts));
      btn.click();
      return true;
    } catch (eP) {
      try {
        btn.click();
        return true;
      } catch (eC) {
        return false;
      }
    }
  }

  function clickSendButton() {
    var btn = sendButtonEnabled();
    if (pressButton(btn)) return true;
    try {
      var el = findComposer();
      var form = el && el.closest ? el.closest("form") : null;
      if (form && typeof form.requestSubmit === "function") {
        form.requestSubmit(btn || undefined);
        return true;
      }
    } catch (eS) {}
    return false;
  }

  function waitForSendReady(timeoutMs) {
    return new Promise(function (resolve) {
      var t0 = Date.now();
      function tick() {
        var btn = sendButtonEnabled();
        if (btn) return resolve(btn);
        if (Date.now() - t0 > timeoutMs) return resolve(null);
        setTimeout(tick, 200);
      }
      tick();
    });
  }

  function waitForSendConfirm(timeoutMs) {
    var usersBefore = (turnsByRole("user") || []).length;
    return new Promise(function (resolve) {
      var t0 = Date.now();
      function tick() {
        var users = (turnsByRole("user") || []).length;
        if (users > usersBefore) return resolve(true);
        if (typeof isGenerating === "function" && isGenerating()) return resolve(true);
        if (Date.now() - t0 > timeoutMs) return resolve(false);
        setTimeout(tick, 250);
      }
      setTimeout(tick, 300);
    });
  }

  /** Type into the real editor, wait for Send to enable, press it, confirm the turn left. */
  function fillAndSendPing(text) {
    if (!typePing(text)) return Promise.resolve(false);
    showTestOverlay("Sending the test message…");
    return sleep(400).then(function () {
      if (!composerHasText(text)) typePing(text);
      return waitForSendReady(4000);
    }).then(function (btn) {
      if (btn) pressButton(btn);
      else if (!clickSendButton()) return false;
      return waitForSendConfirm(4000);
    });
  }

  function waitForAssistantReply(timeoutMs) {
    return new Promise(function (resolve) {
      var t0 = Date.now();
      function tick() {
        var text = currentAssistantText();
        if (text && text.length > 1) return resolve({ ok: true, text: text });
        if (chatShowsError()) return resolve({ ok: false, reason: "chat_error" });
        if (Date.now() - t0 > timeoutMs) return resolve({ ok: false, reason: "no_reply" });
        setTimeout(tick, 500);
      }
      setTimeout(tick, 600);
    });
  }

  function runReplyTest() {
    showTestOverlay("Waiting for the ChatGPT composer…");
    return waitForComposer(UNLOCK_TEST.composerWaitMs).then(function (has) {
      if (!has) return { ok: false, reason: "no_composer" };
      // Guest Ask-anything looks like a composer. Never type until login chrome is real.
      if (pageHasLoginWall() && !pageHasSignedInChrome()) {
        return { ok: false, reason: "login_wall" };
      }
      var ping = UNLOCK_TEST.pingText;
      return fillAndSendPing(ping).then(function (sent) {
        if (!sent) {
          return sleep(400).then(function () {
            return fillAndSendPing(ping);
          }).then(function (again) {
            if (!again) return { ok: false, reason: "send_failed" };
            showTestOverlay("Waiting up to 12 seconds for a reply…");
            return waitForAssistantReply(UNLOCK_TEST.replyWaitMs);
          });
        }
        showTestOverlay("Waiting up to 12 seconds for a reply…");
        return waitForAssistantReply(UNLOCK_TEST.replyWaitMs);
      });
    });
  }

  function isEk2Ui(el) {
    try {
      return !!(
        el &&
        el.closest &&
        (el.closest("#ek2-panel") || el.closest("#ek2-fab") || el.closest("#ek2-test-overlay"))
      );
    } catch (e) {
      return false;
    }
  }

  function pageBodyText() {
    try {
      return String((document.body && (document.body.innerText || document.body.textContent)) || "");
    } catch (e) {
      return "";
    }
  }

  /** Logged-in ChatGPT paints this sidebar even when history fails to load. */
  function pageHasLoggedInShell() {
    try {
      var text = pageBodyText();
      if (/unable to load history/i.test(text)) return true;
      var nav = document.querySelector("nav");
      var navText = String((nav && (nav.innerText || nav.textContent)) || "");
      var side = navText || text;
      if (/new chat/i.test(side) && /library/i.test(side) && !/Sign up for free/i.test(text)) {
        return true;
      }
    } catch (e) {}
    return false;
  }

  /** Guest CTAs across EN / PT / ES / FR / DE — used so locale UIs don't false-login. */
  function pageHasGuestCtaText(text) {
    var t = String(text || "");
    if (/Sign up for free|Log in or sign up|Continue with Google/i.test(t)) return true;
    if (/Cadastre-se gr[aá]tis|Inscreva-se gr[aá]tis|Criar uma conta|Entrar ou se cadastrar/i.test(t)) return true;
    if (/Reg[ií]strate gratis|Inicia sesi[oó]n|Crear cuenta/i.test(t)) return true;
    if (/Inscrivez-vous gratuitement|Se connecter|Cr[eé]er un compte/i.test(t)) return true;
    if (/Kostenlos registrieren|Anmelden|Konto erstellen/i.test(t)) return true;
    return false;
  }

  /**
   * Phone / slim ChatGPT home often has no profile-button test id and no
   * desktop sidebar. The logged-in greeting ("What's on the agenda today?")
   * plus a composer and no guest Log in / Sign up is enough.
   */
  function pageHasLoggedInHomeGreeting() {
    try {
      var text = pageBodyText();
      if (!text) return false;
      if (pageHasGuestCtaText(text)) return false;
      if (!composerPresent()) return false;
      // Guest phone copy — do not treat as signed in (EN + PT + ES).
      if (/what.?s on your mind today/i.test(text)) return false;
      if (/o que (voc[eê]|voce) tem em mente/i.test(text)) return false;
      if (/qu[eé] tienes en mente/i.test(text)) return false;
      if (/what.?s on the agenda today/i.test(text)) return true;
      if (/what should we work on/i.test(text)) return true;
      if (/how can i help you today/i.test(text)) return true;
      if (/como posso ajudar/i.test(text)) return true;
      if (/en qu[eé] puedo ayudarte/i.test(text)) return true;
      if (/comment puis-je vous aider/i.test(text)) return true;
      if (/good to see you|bom te ver|que bom te ver|me alegra verte/i.test(text) && !pageHasGuestAuthButtons()) {
        return true;
      }
    } catch (e) {}
    return false;
  }

  /**
   * Strong signed-in chrome: sidebar history, Chat|Work, agenda home, or an open
   * conversation. Name-only frozen Go pages do NOT qualify.
   */
  function pageHasStrongSignedInChrome() {
    try {
      if (pageHasLoginWall() && !pageHasSignedInChrome()) return false;
      if (pageHasWorkspaceTabs()) return true;
      if (pageHasLoggedInShell()) return true;
      if (pageHasLoggedInHomeGreeting()) return true;
      if (/\/c\//.test(String(location.pathname || ""))) return true;
      if (document.querySelector('nav a[href*="/c/"], [data-testid="history-item"]')) return true;
      if (document.querySelector("[data-message-author-role]")) return true;
    } catch (e) {}
    return false;
  }

  /** Chat | Work workspace toggle — logged-in ChatGPT chrome on phone/desktop. */
  function pageHasWorkspaceTabs() {
    try {
      if (pageHasGuestAuthButtons() || pageHasGuestCtaText(pageBodyText())) return false;
      if (!composerPresent()) return false;
      var nodes = document.querySelectorAll("a,button,[role='button'],[role='tab']");
      var hasChat = false;
      var hasWork = false;
      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i];
        if (isEk2Ui(n) || !isVisibleEl(n)) continue;
        var tx = String(n.textContent || "")
          .replace(/\s+/g, " ")
          .trim();
        if (/^Chat$/i.test(tx)) hasChat = true;
        if (/^Work$/i.test(tx) || /^Trabalho$/i.test(tx) || /^Trabajo$/i.test(tx)) hasWork = true;
      }
      return hasChat && hasWork;
    } catch (e) {}
    return false;
  }

  function pageHasGuestAuthButtons() {
    try {
      var nodes = document.querySelectorAll("a,button,[role='button']");
      var signUpForFree = false;
      var signUp = false;
      var logIn = false;
      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i];
        if (isEk2Ui(n) || !isVisibleEl(n)) continue;
        var tx = String(n.textContent || "")
          .replace(/\s+/g, " ")
          .trim();
        if (/^Sign up for free$/i.test(tx)) signUpForFree = true;
        if (/^Cadastre-se gr[aá]tis$/i.test(tx) || /^Inscreva-se gr[aá]tis$/i.test(tx)) signUpForFree = true;
        if (/^Reg[ií]strate gratis$/i.test(tx) || /^Inscrivez-vous gratuitement$/i.test(tx)) signUpForFree = true;
        if (/^Sign up$/i.test(tx) || /^Cadastre-se$/i.test(tx) || /^Registrarse$/i.test(tx)) signUp = true;
        if (/^Log in$/i.test(tx) || /^Entrar$/i.test(tx) || /^Iniciar sesi[oó]n$/i.test(tx) || /^Anmelden$/i.test(tx)) {
          logIn = true;
        }
      }
      return decideLoginWall({
        signedInChrome: false,
        signUpForFree: signUpForFree,
        signUp: signUp,
        logIn: logIn,
      });
    } catch (e) {}
    return false;
  }

  function pageHasSignedInChrome() {
    try {
      if (pageHasLoggedInShell()) return true;
      if (pageHasLoggedInHomeGreeting()) return true;
      if (pageHasWorkspaceTabs()) return true;
      if (
        document.querySelector(
          '[data-testid="profile-button"], [data-testid="accounts-profile-button"], [data-testid="profile-menu-button"], [data-testid="user-menu"], button[aria-label*="Open profile" i], button[aria-label*="account menu" i], button[aria-label*="profile" i]',
        )
      ) {
        return true;
      }
      if (document.querySelector("[data-message-author-role]")) return true;
      if (/\/c\//.test(String(location.pathname || "")) && composerPresent()) return true;
      if (document.querySelector('nav a[href*="/c/"], [data-testid="history-item"]')) return true;
    } catch (e) {}
    return false;
  }

  /** Current ChatGPT auth page: "Log in or sign up" and Continue with Google. */
  function pageHasAuthChooser() {
    try {
      var text = pageBodyText();
      if (/log in or sign up/i.test(text) && /continue with google/i.test(text)) return true;
      if (/entrar ou se cadastrar/i.test(text) && /continuar com o google/i.test(text)) return true;
      if (/inicia sesi[oó]n o reg[ií]strate/i.test(text) && /continuar con google/i.test(text)) return true;
    } catch (e) {}
    return false;
  }

  /** Guest chatgpt.com shows "Sign up for free" + header Log in. Logged-in chrome wins. */
  function pageHasLoginWall() {
    try {
      if (pageHasAuthChooser()) return true;
      if (pageHasSignedInChrome()) return false;
      var pageText = pageBodyText();
      // Guest homepage from the phone recording: header Log in, "What's on your mind today?", Ask anything.
      if (/what.?s on your mind today/i.test(pageText)) return true;
      if (/o que (voc[eê]|voce) tem em mente/i.test(pageText)) return true;
      if (/qu[eé] tienes en mente/i.test(pageText)) return true;
      if (pageHasGuestCtaText(pageText) && !composerPresent()) return true;
      return pageHasGuestAuthButtons();
    } catch (e) {
      return false;
    }
  }

  function pageLooksSignedIn() {
    return isUnlockSignedIn({});
  }

  /**
   * One signed-in check for unlock. Guest Ask-anything + composer alone is NOT
   * signed in. Session probe / real chrome / turns / history / agenda home win.
   */
  function isUnlockSignedIn(opts) {
    opts = opts || {};
    try {
      var authChooser = pageHasAuthChooser();
      var wall = authChooser || pageHasLoginWall();
      if (opts.chromeState === "wall") wall = true;
      return decideSignedIn({
        sessionOk: !!opts.sessionOk,
        profile: pageHasSignedInChrome(),
        userTurns: !!document.querySelector("[data-message-author-role]"),
        conversation: /\/c\//.test(String(location.pathname || "")),
        history: !!document.querySelector('nav a[href*="/c/"], [data-testid="history-item"]'),
        loginWall: wall,
      });
    } catch (e) {}
    return false;
  }

  /** Photo-2 hang: signed in, user message sent, blue dot, no assistant text. */
  function chatLooksDeadHang() {
    try {
      var users = turnsByRole("user");
      if (!users || !users.length) return false;
      var text = currentAssistantText();
      if (text && text.length > 1) return false;
      return !!(isGenerating() || chatShowsError());
    } catch (e) {
      return false;
    }
  }

  function waitForAuthChrome(timeoutMs) {
    return new Promise(function (resolve) {
      var t0 = Date.now();
      function tick() {
        if (pageLooksSignedIn()) return resolve("in");
        // Do not settle on "wall" early — ChatGPT flashes Log in / Sign up while
        // a real session hydrates. Wait out the timeout, then decide.
        if (Date.now() - t0 > timeoutMs) return resolve(pageLooksSignedIn() ? "in" : pageHasLoginWall() ? "wall" : "unknown");
        setTimeout(tick, 350);
      }
      setTimeout(tick, 250);
    });
  }

  /**
   * After Unlock reload (?ek_ok=1): stay only when ChatGPT session has a user.
   * The guest homepage has an Ask-anything box — that used to mark "ready" and
   * leave the buyer on Log in / Sign up.
   */
  function watchAfterUnlock() {
    var ekOk = false;
    try {
      ekOk = /(?:\?|&)ek_ok=/.test(String(location.search || ""));
    } catch (eS) {}
    pingKillExpired();
    if (!ekOk && !looksExpiredPage()) return;
    if (!ekOk && ssNum("ek2_ready")) {
      pingKillExpired();
      return;
    }

    showTestOverlay("Confirming you are signed in…");
    // Keep the EliteKeys panel closed — it sits above the test overlay and a
    // Log in / Active tap was restarting Unlock (refresh loop on phone).
    setStatus("Checking this ChatGPT login…", "ok");

    Promise.all([getAutoSwaps(), getReinjected(), waitForAuthChrome(10000), probeChatCapable()]).then(function (pair) {
      var swaps = pair[0];
      var reinjected = pair[1];
      var chromeState = pair[2];
      var u = pair[3] || {};

      // Fail closed on proven-dead APIs before trusting page chrome.
      var probeTries = ssNum("ek2_probe_tries");
      var gate = decideUnlockTest(u, probeTries, UNLOCK_TEST);
      if (gate.action === "retry") {
        ssSet("ek2_probe_tries", probeTries + 1);
        showTestOverlay("Cloudflare — retrying the login check…");
        setTimeout(function () {
          watchAfterUnlock();
        }, 1200);
        return;
      }
      if (gate.action === "swap") {
        ssSet("ek2_probe_tries", 0);
        hopUnlock("Auth probe failed (" + (gate.reason || (u && u.reason) || "dead") + ")", {
          burnBound: isAuthDeadReason(gate.reason || (u && u.reason)),
          overlay: "This account cannot use ChatGPT — switching…",
        });
        return;
      }
      ssSet("ek2_probe_tries", 0);

      var signedIn =
        isUnlockSignedIn({
          sessionOk: sessionLooksLive(u),
          chromeState: chromeState,
        }) || chromeState === "in";
      var d = decideHop({
        loginWall: !signedIn && (chromeState === "wall" || pageHasLoginWall()),
        sessionOk: signedIn,
        reinjected: !!reinjected,
        autoSwaps: swaps,
        maxAutoSwaps: MAX_AUTO_SWAPS,
      });
      if (d.action === "ping") {
        proveChatWorks(swaps);
        return;
      }
      if (d.action === "reinject") {
        showTestOverlay("Still on the Log in page — applying the account again…");
        setReinjected(true);
        loadLastCookies().then(function (cookies) {
          if (!cookies) {
            hopUnlock("No stored cookies to re-apply", {
              overlay: "Still signed out — trying another account…",
            });
            return;
          }
          bg({ type: "EK_UNLOCK", cookies: cookies }).then(function (r) {
            if (!r || !r.ok) {
              var reErr = (r && r.error) || "Re-apply failed";
              if (isUnlockNavigationError(reErr)) return;
              hopUnlock(reErr, {
                overlay: "Still signed out — trying another account…",
              });
            }
          });
        });
        return;
      }
      if (d.action === "swap" || d.action === "soft_reset_swap") {
        if (d.action === "soft_reset_swap") resetAutoSwaps();
        hopUnlock("ChatGPT stayed on the Log in page (" + (d.reason || "no_session") + ")", {
          overlay: "Still signed out — trying another account…",
        });
        return;
      }
      hideTestOverlay();
      setStatus(stopMessage(signedIn), "err");
    });
  }

  function stopMessage(signedIn) {
    if (signedIn) {
      return "This ChatGPT account is signed in but is not answering. Click Log in to ChatGPT to get a working one.";
    }
    return "ChatGPT is still signed out. Click Log in to ChatGPT once more. Do not click ChatGPT's own Log in.";
  }

  function proveChatWorks(swaps) {
    showTestOverlay("Logged in — waiting 3 seconds for ChatGPT to load…");
    setStatus("Signed in. Waiting 3 seconds, then sending a test message.", "ok");
    var hung = chatLooksDeadHang();
    var test = hung
      ? Promise.resolve({ ok: false, reason: "blue_dot_no_reply" })
      : sleep(UNLOCK_TEST.loadWaitMs).then(function () {
          return runReplyTest();
        });
    test
      .then(function (r) {
        // Never treat guest Ask-anything as signed in (composer alone is not enough).
        // Workspace tabs / locale greetings / a user turn count as signed-in chrome.
        var signedIn =
          pageLooksSignedIn() ||
          pageHasWorkspaceTabs() ||
          !!(lastUserTurn && lastUserTurn()) ||
          !!(r && r.ok);
        var strong = pageHasStrongSignedInChrome();
        if (decideUnlockKeep(r, signedIn, strong) === "ready") {
          markUnlockReady();
          return;
        }
        // Cap hit on a visible login → stick instead of soft-reset hopping forever.
        if (swaps >= MAX_AUTO_SWAPS) {
          if (signedIn || strong) {
            markUnlockReady();
            return;
          }
          resetAutoSwaps();
        }
        // login_wall / send_failed on a guest page → signed-out hop.
        // no_reply after we already decided sessionOk → "didn't reply" (not "signed out").
        var guestFail = /login_wall|no_composer/i.test(String((r && r.reason) || ""));
        var lookSignedOut = !signedIn && (guestFail || pageHasLoginWall());
        var hopReason = lookSignedOut
          ? "ChatGPT stayed signed out after unlock (" + ((r && r.reason) || "no_reply") + ")"
          : "ChatGPT did not reply after unlock (" + ((r && r.reason) || "no_reply") + ")";
        hopUnlock(hopReason, {
          burnBound: isAuthDeadReason((r && r.reason) || hopReason),
          overlay: lookSignedOut
            ? "Still signed out — switching to another account…"
            : "This account didn't reply — switching to another account…",
        });
      })
      .catch(function () {
        var signedIn = pageLooksSignedIn() || pageHasWorkspaceTabs() || !!(lastUserTurn && lastUserTurn());
        var strong = pageHasStrongSignedInChrome();
        if (swaps >= MAX_AUTO_SWAPS) {
          if (signedIn || strong) {
            markUnlockReady();
            return;
          }
          resetAutoSwaps();
        }
        if (signedIn && strong) {
          markUnlockReady();
          return;
        }
        hopUnlock("ChatGPT login failed after inject", {
          overlay: signedIn
            ? "This account didn't reply — switching to another account…"
            : "Login failed — switching to another account…",
        });
      });
  }

  /** Swap to a fresh pool account using the stored EliteKeys token + last used key. */
  function performSwap(message) {
    return getAutoSwaps().then(function (n) {
      if (n >= MAX_AUTO_SWAPS) {
        // Stick to a visible login instead of soft-reset hopping forever.
        if (pageLooksSignedIn() || pageHasStrongSignedInChrome()) {
          hideTestOverlay();
          markUnlockReady();
          return false;
        }
        resetAutoSwaps();
        n = 0;
      }
      return bumpAutoSwaps().then(function () {
        return Promise.all([loadTok(), loadLastKey()]).then(function (pair) {
          var storedTok = pair[0];
          var meta = pair[1] || {};
          var last = meta.ek2_last_key;
          if (!storedTok || !last || !last.key_text) {
            hideTestOverlay();
            togglePanel(true);
            tok = null;
            clearTok();
            renderLogin("Sign in to EliteKeys again, then tap Log in to ChatGPT.");
            return false;
          }
          tok = storedTok;
          selected = last;
          // Keep panel closed during hops — opening it over the overlay let
          // buyers tap Log in and restart Unlock mid-swap.
          togglePanel(false);
          setStatus(message, "err");
          doUnlock(null, true);
          return true;
        });
      });
    });
  }

  function autoSwapDeadOnce(reason) {
    if (swappedThisLoad) return;
    swappedThisLoad = true;
    loadLastKey().then(function (meta) {
      var lastSwap = Number((meta || {}).ek2_swap_at || 0);
      if (lastSwap && Date.now() - lastSwap < 45000) return;
      try {
        chrome.storage.local.set({ ek2_swap_at: Date.now() });
      } catch (eS) {}
      ssSet("ek2_bound_dead", 1);
      performSwap(
        "ChatGPT said the session expired" +
          (reason ? " (" + reason + ")" : "") +
          " — swapping to a fresh account. Do not click Log in.",
      );
    });
  }

  /* ------------------------------------------------------------ chat health */
  /**
   * Some pool accounts are fully signed in yet cannot produce a reply: the
   * message sends, the conversation is created, the blue dot spins, and no
   * token ever streams. /api/auth/session is green in that state, so the
   * session probe above can't catch it — we have to watch the actual answer.
   *
   * Conservative on purpose: only fires on a signed-in conversation where a
   * user turn went unanswered and the assistant text stopped growing, capped
   * per tab and rate-limited between swaps, so a slow-but-live stream (which
   * keeps growing) never triggers it.
   */
  var CHAT_CFG = {
    tickMs: 2000,
    stuckMs: 14000, // no reply growth this long → unusable
    graceMs: 12000, // give a fresh message at least this long
    cooldownMs: 18000,
    // Post-ready health hops. Server has no lifetime replacement cap — keep
    // recovering a silent account instead of stranding the buyer.
    maxSwaps: 12,
  };
  var chatState = { userAt: 0, lastLen: -1, lastGrowthAt: 0, lastKey: "" };

  function composerPresent() {
    try {
      if (
        document.querySelector(
          "#prompt-textarea, textarea[name='prompt-textarea'], [data-testid='composer']",
        )
      ) {
        return true;
      }
      var nodes = document.querySelectorAll(
        "div.ProseMirror, .ProseMirror[contenteditable='true'], [contenteditable='true'].ProseMirror",
      );
      for (var i = 0; i < nodes.length; i++) {
        if (isVisibleEl(nodes[i]) && !isEk2Ui(nodes[i])) return true;
      }
    } catch (e) {
      return false;
    }
    return false;
  }

  function turnsByRole(role) {
    try {
      return document.querySelectorAll("[data-message-author-role='" + role + "']");
    } catch (e) {
      return [];
    }
  }

  function lastUserTurn() {
    var u = turnsByRole("user");
    return u && u.length ? u[u.length - 1] : null;
  }

  /** Visible assistant text for the newest exchange — 0 while a dead dot spins. */
  function currentAssistantText() {
    try {
      var a = turnsByRole("assistant");
      if (!a || !a.length) return "";
      var last = a[a.length - 1];
      return String(last.innerText || last.textContent || "").trim();
    } catch (e) {
      return "";
    }
  }

  function isGenerating() {
    try {
      if (document.querySelector("[data-testid='stop-button'],button[aria-label*='Stop' i]")) return true;
      if (document.querySelector(".result-streaming")) return true;
    } catch (e) {}
    return false;
  }

  function chatShowsError() {
    try {
      var nodes = document.querySelectorAll('[role="alert"], [data-testid*="error" i], [class*="text-token-text-error"]');
      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i];
        if (isEk2Ui(n) || !isVisibleEl(n)) continue;
        var t = String(n.innerText || n.textContent || "");
        if (
          /something went wrong|error in (?:body|moderation)|network error|unusual activity|too many requests|rate limit|reached your limit/i.test(
            t,
          )
        ) {
          return true;
        }
      }
    } catch (e) {}
    return false;
  }

  function onConversationPage() {
    try {
      return /\/c\//.test(String(location.pathname || "")) || !!lastUserTurn();
    } catch (e) {
      return false;
    }
  }

  function ssNum(k) {
    try {
      return Number(sessionStorage.getItem(k) || "0") || 0;
    } catch (e) {
      return 0;
    }
  }
  function ssSet(k, v) {
    try {
      sessionStorage.setItem(k, String(v));
    } catch (e) {}
  }

  function isAuthDeadReason(reason) {
    return /refresh_error|no_access_token|not logged in|session expired|session_expired/i.test(
      String(reason || ""),
    );
  }

  function decideRecover(flags) {
    // Post-ready chat health: reinject once, then swap. Soft-reset at the cap.
    return decideHop({
      authDead: !!flags.authDead,
      sessionOk: false,
      reinjected: !!flags.reinjected,
      autoSwaps: Number(flags.swaps || 0) || 0,
      maxAutoSwaps: Number(flags.maxSwaps || MAX_AUTO_SWAPS) || 40,
    });
  }

  /**
   * Single unlock hop entry. Always parks the panel closed and goes through
   * performSwap → doUnlock(swap). Burn only when the JWT is proven dead.
   */
  function hopUnlock(reason, opts) {
    opts = opts || {};
    if (opts.burnBound || isAuthDeadReason(reason)) ssSet("ek2_bound_dead", 1);
    showTestOverlay(opts.overlay || "Switching to another ChatGPT account…");
    return performSwap(
      String(reason || "ChatGPT account failed") + " — swapping to a working account. Do not click Log in.",
    );
  }

  function triggerChatSwap(reason, opts) {
    opts = opts || {};
    var testing = !!opts.forceSwap || !!ssNum("ek2_testing");
    var cool = testing ? 4000 : CHAT_CFG.cooldownMs;
    if (Date.now() - ssNum("ek2_chat_last_swap") < cool) return false;
    var authDead = !!opts.burnBound || isAuthDeadReason(reason);
    if (authDead) ssSet("ek2_bound_dead", 1);
    ssSet("ek2_chat_last_swap", Date.now());

    // During unlock proof: one hop path only (no second reinject ladder).
    if (testing) {
      ssSet("ek2_ready", 0);
      hopUnlock(reason, { burnBound: authDead });
      return true;
    }

    // Post-ready chat health still gets one cookie re-apply before burning a hop.
    var plan = decideRecover({
      reinjected: !!ssNum("ek2_reinjected"),
      swaps: ssNum("ek2_chat_swaps"),
      maxSwaps: CHAT_CFG.maxSwaps,
      authDead: authDead,
    });
    if (plan.action === "reinject") {
      ssSet("ek2_reinjected", 1);
      setStatus(reason + " — re-applying this account (does not use a replacement).", "err");
      togglePanel(false);
      loadLastCookies().then(function (cookies) {
        if (!cookies) {
          ssSet("ek2_chat_swaps", ssNum("ek2_chat_swaps") + 1);
          hopUnlock(reason, { burnBound: authDead });
          return;
        }
        bg({ type: "EK_UNLOCK", cookies: cookies }).then(function (r) {
          if (!r || !r.ok) {
            var reinjErr = (r && r.error) || "";
            if (isUnlockNavigationError(reinjErr)) return;
            ssSet("ek2_chat_swaps", ssNum("ek2_chat_swaps") + 1);
            hopUnlock(reason, { burnBound: authDead });
          }
        });
      });
      return true;
    }
    if (plan.action === "swap" || plan.action === "soft_reset_swap") {
      ssSet("ek2_chat_swaps", ssNum("ek2_chat_swaps") + 1);
      ssSet("ek2_ready", 0);
      hopUnlock(reason, { burnBound: authDead });
      return true;
    }
    hideTestOverlay();
    togglePanel(true);
    setStatus(
      "This ChatGPT account still isn't answering. Click Log in to ChatGPT to retry, or contact support for a new Mix/Plus code.",
      "err",
    );
    return false;
  }

  /**
   * Pure decision step, kept side-effect free so the offline suite can drive it
   * through real timelines. v1 shipped a watchdog whose generating check could
   * never fire (`isGenerating() && !isGenerating()`), so the hang it was meant
   * to catch went unrecovered — that class of bug has to be testable.
   *
   * snap: { now, loggedIn, onConversation, userTurns, path, text, generating, hardError }
   * Mutates `st` (the running exchange state) and returns the action to take.
   */
  function decideChatHealth(snap, st, cfg) {
    if (!snap.loggedIn || !snap.onConversation || !snap.userTurns) {
      st.userAt = 0;
      st.lastKey = "";
      return { action: "idle" };
    }
    var now = snap.now;
    // Key the exchange so a new question resets the stuck timer cleanly.
    var key = String(snap.userTurns) + ":" + String(snap.path || "");
    if (key !== st.lastKey) {
      st.lastKey = key;
      st.userAt = now;
      st.lastLen = -1;
      st.lastGrowthAt = now;
    }

    var text = String(snap.text || "");
    if (text.length > st.lastLen) {
      st.lastLen = text.length;
      st.lastGrowthAt = now;
    }

    var awaited = now - (st.userAt || now);
    var sinceGrowth = now - (st.lastGrowthAt || now);

    // A live stream keeps growing. Only stand down while tokens are actually
    // arriving — a spinning dot with zero tokens is the hang we must recover.
    if (snap.generating && text.length > 1) return { action: "streaming" };

    if (snap.hardError && awaited > 4000) {
      return { action: "swap", reason: "ChatGPT returned an error" };
    }
    if (text.length < 2 && awaited > cfg.graceMs && sinceGrowth > cfg.stuckMs) {
      return { action: "swap", reason: "ChatGPT didn't reply" };
    }
    return { action: "wait" };
  }

  function chatHealthTick() {
    try {
      if (!ssNum("ek2_ready") || ssNum("ek2_testing")) return;
      var snap = {
        now: Date.now(),
        loggedIn: composerPresent(),
        onConversation: onConversationPage(),
        userTurns: (turnsByRole("user") || []).length,
        path: String(location.pathname || ""),
        text: currentAssistantText(),
        generating: isGenerating(),
        hardError: chatShowsError(),
      };
      var d = decideChatHealth(snap, chatState, CHAT_CFG);
      if (d.action === "swap") triggerChatSwap(d.reason);
    } catch (e) {}
  }

  // Exported for the offline proof (scripts/e2e-chatgpt-extension-v2.mjs).
  window.__ek2ChatHealth = {
    needsUpdate: extensionNeedsUpdate,
    decide: decideChatHealth,
    recover: decideRecover,
    hop: decideHop,
    interpret: interpretAuthProbe,
    models: modelsLookUsable,
    unlockTest: decideUnlockTest,
    afterUnlock: decideAfterUnlock,
    loginWall: decideLoginWall,
    signedIn: decideSignedIn,
    unlockSignedIn: isUnlockSignedIn,
    canSkip: canSkipOverlayToReady,
    keepHopping: shouldKeepHoppingUnlockError,
    unlockNavError: isUnlockNavigationError,
    unlockKeep: decideUnlockKeep,
    cfg: CHAT_CFG,
    unlockCfg: UNLOCK_TEST,
  };

  // Support diagnostic: window.__ek2ChatgptDiag()
  window.__ek2ChatgptDiag = function () {
    function safeFetch(url, opts) {
      return fetch(url, opts).then(
        function (r) {
          return r.text().then(function (t) {
            return { status: r.status, body: String(t || "").slice(0, 400) };
          });
        },
        function (e) {
          return { status: 0, error: String((e && e.message) || e) };
        },
      );
    }
    return safeFetch("https://chatgpt.com/api/auth/session", {
      credentials: "include",
      cache: "no-store",
    }).then(function (sess) {
      var accessToken = "";
      try {
        accessToken = JSON.parse(sess.body || "{}").accessToken || "";
      } catch (e) {}
      return safeFetch("https://chatgpt.com/backend-api/me", {
        credentials: "include",
        cache: "no-store",
        headers: accessToken ? { Authorization: "Bearer " + accessToken } : {},
      }).then(function (me) {
        return {
          version: "2.0.27",
          composer: composerPresent(),
          hasAccessToken: !!accessToken,
          canChat: me.status === 200,
          ready: !!ssNum("ek2_ready"),
          chatSwaps: ssNum("ek2_chat_swaps"),
          testSwaps: ssNum("ek2_test_swaps"),
          session: sess,
          backendMe: me,
        };
      });
    });
  };

  /* ----------------------------------------------------------- panel shell */
  function buildPanel() {
    panel = mk("div", {
      position: "fixed",
      right: "18px",
      bottom: "76px",
      width: "320px",
      "max-width": "calc(100vw - 24px)",
      "z-index": "2147483646",
      "border-radius": "16px",
      padding: "14px",
      color: "#e8fff5",
      font: "13px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif",
      background: "linear-gradient(165deg,#0d221b,#071310)",
      border: "1px solid rgba(94,233,181,.25)",
      "box-shadow": "0 18px 50px rgba(0,0,0,.5)",
      display: "none",
    });
    panel.id = "ek2-panel";

    var header = mk("div", { display: "flex", "align-items": "center", gap: "8px", margin: "0 0 12px" });
    var title = mk("span", { font: "800 14px/1.2 system-ui", color: "#eafff7" }, "EliteKeys ChatGPT");
    var ver = mk("span", { "font-size": "10px", "font-weight": "700", color: ACCENT, opacity: ".8" }, "v2.0.27");
    var close = mk(
      "button",
      {
        "margin-left": "auto",
        background: "transparent",
        border: "0",
        color: "rgba(232,255,245,.6)",
        cursor: "pointer",
        font: "800 16px/1 system-ui",
      },
      "×",
    );
    close.addEventListener("click", function () {
      togglePanel(false);
    });
    header.appendChild(title);
    header.appendChild(ver);
    header.appendChild(close);
    panel.appendChild(header);

    body = mk("div", {});
    panel.appendChild(body);

    statusEl = mk("div", { "min-height": "15px", "font-size": "11px", "margin-top": "10px" });
    panel.appendChild(statusEl);

    document.documentElement.appendChild(panel);
  }

  function buildFab() {
    // Phone (Lemur/Orion): compact bottom-right pill (left:auto + max-content).
    // PC: same pill — never stretch full width.
    fab = mk(
      "button",
      {
        position: "fixed",
        left: "auto",
        right: EK2_PHONE ? "14px" : "18px",
        bottom: EK2_PHONE ? "14px" : "18px",
        width: "max-content",
        "z-index": "2147483647",
        display: "inline-flex",
        "align-items": "center",
        gap: EK2_PHONE ? "6px" : "8px",
        "border-radius": "999px",
        padding: EK2_PHONE ? "9px 12px" : "11px 15px",
        border: "0",
        cursor: "pointer",
        font: EK2_PHONE ? "800 12px/1 system-ui,sans-serif" : "800 13px/1 system-ui,sans-serif",
        color: "#04140f",
        background: "linear-gradient(135deg,#5ee9b5,#2f9e74)",
        "box-shadow": "0 10px 30px rgba(47,158,116,.45)",
      },
      "",
    );
    fab.id = "ek2-fab";
    var dot = mk("span", {
      width: EK2_PHONE ? "6px" : "8px",
      height: EK2_PHONE ? "6px" : "8px",
      "border-radius": "50%",
      background: "#04140f",
      opacity: ".85",
    });
    var label = mk("span", {}, "EliteKeys ChatGPT");
    fab.appendChild(dot);
    fab.appendChild(label);
    fab.addEventListener("click", function () {
      togglePanel();
    });
    document.documentElement.appendChild(fab);
  }

  function renderOutdated() {
    clearBody();
    var msg = extNotice || "This extension is outdated. Redeem your key again at https://elitekeys.site/ and download the new extension.";
    body.appendChild(mk("p", {
      margin: "0 0 12px",
      "font-size": "13px",
      color: "#ffb4b4",
      "line-height": "1.5",
    }, msg));
    var zip = "https://elitekeys.site/api/public/install/chatgpt-extension-v2.zip";
    if (EK2_PLAT === "lemur") zip = "https://elitekeys.site/api/public/install/chatgpt-extension-lemur.zip";
    if (EK2_PLAT === "orion") zip = "https://elitekeys.site/api/public/install/chatgpt-extension-orion.zip";
    var dl = mk("a", {
      display: "block",
      color: ACCENT,
      "font-weight": "800",
      "margin-bottom": "8px",
      "text-decoration": "underline",
    }, "Download the new extension");
    dl.href = zip;
    dl.target = "_blank";
    dl.rel = "noopener";
    body.appendChild(dl);
    var redeem = mk("a", {
      display: "block",
      color: ACCENT,
      "font-weight": "800",
      "text-decoration": "underline",
    }, "Redeem your key again");
    redeem.href = "https://elitekeys.site/";
    redeem.target = "_blank";
    redeem.rel = "noopener";
    body.appendChild(redeem);
  }
  function refreshExtensionVersion() {
    if (extVersionChecked) return Promise.resolve(null);
    if (extVersionPromise) return extVersionPromise;
    extVersionPromise = bridgeRequest("/challenge", { method: "GET" }).then(function (j) {
      extVersionChecked = true;
      var ext = j && j.ext;
      if (extensionNeedsUpdate(EK2_VERSION, ext, EK2_PLAT)) {
        extOutdated = true;
        extNotice = (ext && ext.message) || "This extension is outdated. Redeem your key again at https://elitekeys.site/ and download the new extension.";
        try {
          if (panel && panel.style.getPropertyValue("display") === "block") renderOutdated();
        } catch (eShow) {}
      }
      return j;
    }, function () {
      extVersionPromise = null;
      return null;
    });
    return extVersionPromise;
  }
  function togglePanel(force) {
    var show = typeof force === "boolean" ? force : panel.style.getPropertyValue("display") === "none";
    // Never cover the unlock proof overlay — that restart loop is what buyers
    // reported as "keeps refreshing" when they tapped Log in / Active.
    if (show && ssNum("ek2_testing")) show = false;
    panel.style.setProperty("display", show ? "block" : "none");
    if (show) {
      refreshExtensionVersion().then(function () {
        if (extOutdated) {
          renderOutdated();
          return;
        }
        if (tok) {
          renderKeys();
          loadKeys();
        } else {
          renderLogin();
        }
      });
    }
  }

  function mount() {
    if (mounted) return;
    if (!document.body) {
      requestAnimationFrame(mount);
      return;
    }
    mounted = true;
    buildPanel();
    buildFab();
    refreshExtensionVersion();
    watchAfterUnlock();
    bg({ type: "EK_INSTALL_AUTH_HOOK" });
    try {
      document.addEventListener("ek2-auth-fail", function (ev) {
        var d = (ev && ev.detail) || {};
        var url = String(d.url || "");
        // /api/auth/session and /backend-api/me 401/403 during hydrate are normal.
        // Swapping on those during unlock proof caused: stuck on Activating… then
        // infinite chatgpt.com refresh. Only a conversation auth failure means the
        // account cannot chat — watchAfterUnlock already owns session/me probes.
        if (!/\/backend-api\/(?:f\/)?conversation/.test(url)) return;
        triggerChatSwap("ChatGPT API " + (d.status || 401) + " — token rejected", {
          forceSwap: !!ssNum("ek2_testing"),
        });
      });
    } catch (eHook) {}
    try {
      setInterval(chatHealthTick, CHAT_CFG.tickMs);
    } catch (eCH) {}
    // Keep the button alive across ChatGPT's SPA re-renders.
    setInterval(function () {
      if (!document.getElementById("ek2-fab")) {
        try {
          document.documentElement.appendChild(fab);
        } catch (e) {}
      }
      if (!document.getElementById("ek2-panel")) {
        try {
          document.documentElement.appendChild(panel);
        } catch (e) {}
      }
      if (ssNum("ek2_testing") && !document.getElementById("ek2-test-overlay")) {
        showTestOverlay("Testing this ChatGPT account…");
      }
    }, 1500);
  }

  loadTok().then(function (v) {
    tok = v || null;
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mount);
  } else {
    mount();
  }
  window.addEventListener("load", mount);
})();
