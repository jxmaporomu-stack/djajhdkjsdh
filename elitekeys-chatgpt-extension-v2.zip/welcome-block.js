// EliteKeys ChatGPT v2 — Welcome-back + session-expired blocker
// (document_start, isolated world).
//
// Two ChatGPT overlays hijack a working tab after cookie inject:
//   1. Google "Welcome back / Choose an account" (SSO trap).
//   2. "Your session has expired / Please log in again to continue using the app."
//      ChatGPT's SPA paints this over a just-injected (even live) profile. The
//      sidebar can already show the new name/plan while this modal stays up.
//      Clicking its "Log in" button is Google SSO — never the EliteKeys flow.
//
// We hide those dialogs IN PLACE (never detach React nodes — that skips
// unmount cleanup and leaves pointer-events:none on <body>) and restore
// clickability. If the cookie is actually dead, content.js probes
// /api/auth/session and auto-swaps.
(function () {
  "use strict";
  if (window.__ek2WelcomeBlock) return;
  window.__ek2WelcomeBlock = { version: "2.0.5" };

  var TRAP_RE =
    /Welcome back|Choose an account|Log in to another account|@gmail\.com|@googlemail\.com|your session has expired|session has expired|session expired|continue using the app|please log in again/i;

  function isEkUi(el) {
    try {
      return !!(el && el.closest && el.closest("#ek2-fab,#ek2-panel"));
    } catch (e) {
      return false;
    }
  }

  function bodyText() {
    try {
      return String((document.body && (document.body.textContent || "")) || "");
    } catch (e) {
      return "";
    }
  }

  function looksExpiredText(t) {
    t = String(t || "");
    if (/your session has expired/i.test(t) && /please log in again|log in again/i.test(t)) return true;
    if (/session has expired/i.test(t) && /\blog in\b/i.test(t)) return true;
    if (/session expired/i.test(t) && /continue using the app/i.test(t)) return true;
    return false;
  }

  function looksWelcomeText(t) {
    t = String(t || "");
    if (/Welcome back/i.test(t) && /Choose an account/i.test(t)) return true;
    if (/Welcome back/i.test(t) && /Log in to another account/i.test(t)) return true;
    if (/Welcome back/i.test(t) && /@gmail\.com|@googlemail\.com/i.test(t)) return true;
    if (/Choose an account to continue/i.test(t) && /@gmail\.com/i.test(t)) return true;
    return false;
  }

  function looksTrapText(t) {
    return looksExpiredText(t) || looksWelcomeText(t);
  }

  function neutralizeInPlace(el) {
    if (!el || isEkUi(el)) return false;
    try {
      el.setAttribute("data-ek2-hidden", "1");
    } catch (eA) {}
    try {
      if (typeof el.close === "function" && el.open) el.close();
    } catch (eC) {}
    try {
      // Hide without detaching — React owns these nodes.
      el.style.setProperty("display", "none", "important");
      el.style.setProperty("visibility", "hidden", "important");
      el.style.setProperty("opacity", "0", "important");
      el.style.setProperty("pointer-events", "none", "important");
      el.style.setProperty("height", "0", "important");
      el.style.setProperty("width", "0", "important");
      el.style.setProperty("overflow", "hidden", "important");
    } catch (eS) {
      return false;
    }
    return true;
  }

  function restoreDocInteractivity() {
    try {
      var nodes = [document.documentElement, document.body];
      for (var i = 0; i < nodes.length; i++) {
        var el = nodes[i];
        if (!el || !el.style) continue;
        try {
          el.style.removeProperty("pointer-events");
          el.style.setProperty("pointer-events", "auto", "important");
        } catch (e0) {}
        try {
          el.style.removeProperty("overflow");
        } catch (e1) {}
        try {
          el.removeAttribute("inert");
        } catch (e2) {}
        try {
          if (el.getAttribute && el.getAttribute("aria-hidden") === "true") el.removeAttribute("aria-hidden");
        } catch (e3) {}
      }
    } catch (e) {}
  }

  function isBlockingOverlay(el) {
    if (!el || el === document.body || el === document.documentElement) return false;
    if (isEkUi(el)) return false;
    try {
      if (el.getAttribute && el.getAttribute("data-ek2-hidden") === "1") return false;
    } catch (eA) {}
    var st = null;
    try {
      st = window.getComputedStyle ? window.getComputedStyle(el) : null;
    } catch (eS) {}
    if (st && st.pointerEvents === "none") return false;
    var pos = st ? st.position : "";
    if (pos !== "fixed" && pos !== "absolute") {
      // Dialog role still counts even if ChatGPT didn't set position yet.
      var role = "";
      try {
        role = String((el.getAttribute && el.getAttribute("role")) || el.tagName || "");
      } catch (eR) {}
      if (!/dialog/i.test(role) && el.tagName !== "DIALOG") return false;
    }
    try {
      if (el.querySelector && el.querySelector("#prompt-textarea, [data-testid='composer'], #ek2-fab, #ek2-panel")) {
        return false;
      }
    } catch (eQ) {}
    var tx = "";
    try {
      tx = String(el.textContent || "");
    } catch (eT) {}
    if (looksTrapText(tx)) return true;
    try {
      var r = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
      var vw = window.innerWidth || 0;
      var vh = window.innerHeight || 0;
      if (r && vw > 0 && vh > 0 && r.width >= vw * 0.5 && r.height >= vh * 0.5 && tx.trim().length < 80) {
        return true;
      }
    } catch (eB) {}
    return false;
  }

  function peelBackdrops() {
    try {
      var cx = Math.floor((window.innerWidth || 0) / 2);
      var cy = Math.floor((window.innerHeight || 0) / 2);
      for (var n = 0; n < 8 && cx > 0 && cy > 0; n++) {
        var top = document.elementFromPoint ? document.elementFromPoint(cx, cy) : null;
        if (!isBlockingOverlay(top)) break;
        if (!neutralizeInPlace(top)) break;
      }
    } catch (e) {}
  }

  function killModals() {
    var raw = bodyText();
    var worth = TRAP_RE.test(raw) || looksTrapText(raw);
    var killed = 0;
    if (worth) {
      var nodes = [];
      try {
        nodes = document.querySelectorAll(
          "div[role='dialog'],dialog,[aria-modal='true'],[popover],[data-testid*='login'],[data-state='open']",
        );
      } catch (eQ) {
        nodes = [];
      }
      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i];
        if (isEkUi(n)) continue;
        var tx = "";
        try {
          tx = String(n.textContent || "");
        } catch (eT) {
          continue;
        }
        if (!looksTrapText(tx) && !TRAP_RE.test(tx)) continue;
        if (neutralizeInPlace(n)) killed += 1;
      }
    }
    if (killed || looksExpiredText(raw) || looksWelcomeText(raw)) {
      restoreDocInteractivity();
      peelBackdrops();
    }
    return killed;
  }

  function eatExpiredLoginClick(e) {
    try {
      var t = e && e.target;
      if (!t || !t.closest) return;
      var dlg = t.closest("div[role='dialog'],dialog,[aria-modal='true'],[popover]");
      if (!dlg || isEkUi(dlg)) return;
      var tx = String(dlg.textContent || "");
      if (!looksExpiredText(tx) && !looksWelcomeText(tx)) return;
      // ChatGPT's "Log in" here is Google SSO. Swallow it and hide the overlay.
      if (e.preventDefault) e.preventDefault();
      if (e.stopPropagation) e.stopPropagation();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
      neutralizeInPlace(dlg);
      restoreDocInteractivity();
      peelBackdrops();
    } catch (err) {}
  }

  function askBackground() {
    try {
      chrome.runtime.sendMessage({ type: "EK_KILL_WELCOME" }, function () {
        void chrome.runtime.lastError;
      });
    } catch (e) {}
  }

  function tick() {
    killModals();
  }

  window.__ek2WelcomeBlock.killExpired = killModals;
  window.__ek2WelcomeBlock.looksExpired = function () {
    return looksExpiredText(bodyText());
  };
  window.__ek2WelcomeBlock.looksExpiredText = looksExpiredText;
  window.__ek2WelcomeBlock.neutralizeInPlace = neutralizeInPlace;

  var afterUnlock = false;
  try {
    afterUnlock = /(?:\?|&)ek_ok=/.test(String(location.search || ""));
  } catch (eU) {}

  var count = 0;
  var maxTicks = afterUnlock ? 400 : 200; // ~2 min after unlock, ~60s otherwise
  var iv = setInterval(function () {
    tick();
    count += 1;
    if (count === 2 || count === 8) askBackground();
    if (count > maxTicks) clearInterval(iv);
  }, 300);

  try {
    new MutationObserver(tick).observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
  } catch (e) {}

  try {
    document.addEventListener("click", eatExpiredLoginClick, true);
    document.addEventListener("pointerdown", eatExpiredLoginClick, true);
  } catch (eClk) {}

  document.addEventListener("DOMContentLoaded", tick);
  window.addEventListener("load", function () {
    tick();
    askBackground();
  });
})();
