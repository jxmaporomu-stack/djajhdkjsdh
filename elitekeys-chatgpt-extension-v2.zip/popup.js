// EliteKeys ChatGPT v2 — popup: open chatgpt.com and let the on-page panel do the rest.
(function () {
  "use strict";
  var msg = document.getElementById("msg");
  function setMsg(t) {
    if (msg) msg.textContent = t || "";
  }

  document.getElementById("open-chatgpt").addEventListener("click", function () {
    setMsg("Opening chatgpt.com…");
    try {
      chrome.tabs.create({ url: "https://chatgpt.com/", active: true }, function () {
        setMsg("Opened. Use the green EliteKeys button in the bottom-right.");
        window.close();
      });
    } catch (e) {
      setMsg("Could not open a tab — go to chatgpt.com manually.");
    }
  });
})();
